using System.Runtime.InteropServices;

namespace RewriteAI;

/// <summary>
/// P/Invoke declarations for Win32 hotkey and input simulation APIs.
/// </summary>
internal static class NativeMethods
{
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);

    [DllImport("user32.dll")]
    public static extern uint GetClipboardSequenceNumber();

    // Modifier keys for RegisterHotKey
    public const uint MOD_ALT = 0x0001;
    public const uint MOD_CONTROL = 0x0002;
    public const uint MOD_SHIFT = 0x0004;
    public const uint MOD_NOREPEAT = 0x4000;

    // Virtual key codes
    public const ushort VK_CONTROL = 0x11;
    public const ushort VK_ALT = 0x12;   // VK_MENU
    public const ushort VK_SHIFT = 0x10;
    public const ushort VK_C = 0x43;
    public const ushort VK_V = 0x56;
    public const ushort VK_R = 0x52;

    // SendInput constants
    public const uint INPUT_KEYBOARD = 1;
    public const uint KEYEVENTF_KEYUP = 0x0002;

    // Windows message for hotkey
    public const int WM_HOTKEY = 0x0312;

    [StructLayout(LayoutKind.Sequential)]
    public struct INPUT
    {
        public uint type;
        public INPUTUNION union;
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct INPUTUNION
    {
        // MOUSEINPUT must be part of the union so sizeof(INPUT) matches what Windows expects
        // (40 bytes on x64); otherwise SendInput fails with ERROR_INVALID_PARAMETER.
        [FieldOffset(0)] public MOUSEINPUT mi;
        [FieldOffset(0)] public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MOUSEINPUT
    {
        public int dx;
        public int dy;
        public uint mouseData;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    /// <summary>
    /// Creates a key-down INPUT struct.
    /// </summary>
    public static INPUT KeyDown(ushort vk) => new()
    {
        type = INPUT_KEYBOARD,
        union = new INPUTUNION
        {
            ki = new KEYBDINPUT { wVk = vk, dwFlags = 0 }
        }
    };

    /// <summary>
    /// Creates a key-up INPUT struct.
    /// </summary>
    public static INPUT KeyUp(ushort vk) => new()
    {
        type = INPUT_KEYBOARD,
        union = new INPUTUNION
        {
            ki = new KEYBDINPUT { wVk = vk, dwFlags = KEYEVENTF_KEYUP }
        }
    };
}
