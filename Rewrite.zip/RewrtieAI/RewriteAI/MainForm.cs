namespace RewriteAI;

/// <summary>
/// Hidden form that registers the global hotkey and handles the rewrite workflow.
/// Runs as a system tray icon application.
/// </summary>
internal sealed class MainForm : Form
{
    private const int HOTKEY_ID = 1;
    private readonly RewriteService _rewriteService;
    private readonly NotifyIcon _trayIcon;
    private bool _isProcessing;

    public MainForm(RewriteService rewriteService)
    {
        _rewriteService = rewriteService;

        // Make the form invisible
        ShowInTaskbar = false;
        WindowState = FormWindowState.Minimized;
        FormBorderStyle = FormBorderStyle.None;
        Opacity = 0;

        // Set up system tray icon
        _trayIcon = new NotifyIcon
        {
            Icon = SystemIcons.Application,
            Text = "RewriteAI - Ctrl+Alt+R to rewrite selected text",
            Visible = true
        };

        var contextMenu = new ContextMenuStrip();
        contextMenu.Items.Add("About", null, (_, _) =>
            MessageBox.Show(
                "RewriteAI\n\nSelect text in any application and press Ctrl+Alt+R to rewrite it using AI.\n\nPowered by Semantic Kernel.",
                "RewriteAI",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information));
        contextMenu.Items.Add("-");
        contextMenu.Items.Add("Exit", null, (_, _) => Application.Exit());
        _trayIcon.ContextMenuStrip = contextMenu;

        // Register global hotkey: Ctrl+Alt+R
        if (!NativeMethods.RegisterHotKey(
                Handle,
                HOTKEY_ID,
                NativeMethods.MOD_CONTROL | NativeMethods.MOD_ALT | NativeMethods.MOD_NOREPEAT,
                NativeMethods.VK_R))
        {
            MessageBox.Show(
                "Failed to register hotkey Ctrl+Alt+R.\nAnother application may already be using this combination.",
                "RewriteAI - Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == NativeMethods.WM_HOTKEY && m.WParam == (IntPtr)HOTKEY_ID)
        {
            _ = HandleHotkeyAsync();
        }

        base.WndProc(ref m);
    }

    private async Task HandleHotkeyAsync()
    {
        if (_isProcessing)
            return;

        _isProcessing = true;
        _trayIcon.Text = "RewriteAI - Processing...";

        try
        {
            // Remember which window was active (the one with selected text)
            var foregroundWindow = NativeMethods.GetForegroundWindow();

            // Copy selected text from the active application
            var selectedText = await ClipboardHelper.CopySelectedTextAsync();

            if (string.IsNullOrWhiteSpace(selectedText))
            {
                _trayIcon.ShowBalloonTip(2000, "RewriteAI", "No text selected.", ToolTipIcon.Warning);
                return;
            }

            // Show processing notification
            _trayIcon.ShowBalloonTip(2000, "RewriteAI", "Rewriting text...", ToolTipIcon.Info);

            // Rewrite using Semantic Kernel
            var rewrittenText = await _rewriteService.RewriteAsync(selectedText);

            if (string.IsNullOrWhiteSpace(rewrittenText))
            {
                _trayIcon.ShowBalloonTip(2000, "RewriteAI", "Rewrite returned empty result.", ToolTipIcon.Warning);
                return;
            }

            // Bring the original window back to focus
            NativeMethods.SetForegroundWindow(foregroundWindow);
            await Task.Delay(100);

            // Paste the rewritten text
            await ClipboardHelper.PasteTextAsync(rewrittenText);

            _trayIcon.ShowBalloonTip(2000, "RewriteAI", "Text rewritten successfully!", ToolTipIcon.Info);
        }
        catch (Exception ex)
        {
            _trayIcon.ShowBalloonTip(3000, "RewriteAI - Error", $"Failed to rewrite: {ex.Message}", ToolTipIcon.Error);
        }
        finally
        {
            _isProcessing = false;
            _trayIcon.Text = "RewriteAI - Ctrl+Alt+R to rewrite selected text";
        }
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        NativeMethods.UnregisterHotKey(Handle, HOTKEY_ID);
        _trayIcon.Visible = false;
        _trayIcon.Dispose();
        base.OnFormClosing(e);
    }

    protected override void SetVisibleCore(bool value)
    {
        // Prevent the form from ever showing
        base.SetVisibleCore(false);
    }
}
