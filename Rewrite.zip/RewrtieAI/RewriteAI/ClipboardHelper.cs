using System.Runtime.InteropServices;

namespace RewriteAI;

/// <summary>
/// Handles capturing selected text via simulated Ctrl+C and pasting rewritten text via Ctrl+V.
/// Uses SendInput for reliable keystroke simulation.
/// </summary>
internal static class ClipboardHelper
{
    /// <summary>
    /// Waits for all modifier keys (Ctrl, Alt, Shift) to be physically released
    /// so they don't interfere with simulated keystrokes.
    /// </summary>
    private static async Task WaitForModifierRelease()
    {
        // Wait up to 2 seconds for modifiers to be released
        for (int i = 0; i < 40; i++)
        {
            bool ctrlDown = (NativeMethods.GetAsyncKeyState(NativeMethods.VK_CONTROL) & 0x8000) != 0;
            bool altDown = (NativeMethods.GetAsyncKeyState(NativeMethods.VK_ALT) & 0x8000) != 0;
            bool shiftDown = (NativeMethods.GetAsyncKeyState(NativeMethods.VK_SHIFT) & 0x8000) != 0;

            if (!ctrlDown && !altDown && !shiftDown)
                return;

            await Task.Delay(50);
        }
    }

    /// <summary>
    /// Sends a sequence of inputs using SendInput.
    /// </summary>
    private static void Send(params NativeMethods.INPUT[] inputs)
    {
        NativeMethods.SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<NativeMethods.INPUT>());
    }

    /// <summary>
    /// Simulates Ctrl+C keystroke.
    /// </summary>
    private static void SimulateCopy()
    {
        var inputs = new[]
        {
            NativeMethods.KeyDown(NativeMethods.VK_CONTROL),
            NativeMethods.KeyDown(NativeMethods.VK_C),
            NativeMethods.KeyUp(NativeMethods.VK_C),
            NativeMethods.KeyUp(NativeMethods.VK_CONTROL),
        };
        Send(inputs);
    }

    /// <summary>
    /// Simulates Ctrl+V keystroke.
    /// </summary>
    private static void SimulatePaste()
    {
        var inputs = new[]
        {
            NativeMethods.KeyDown(NativeMethods.VK_CONTROL),
            NativeMethods.KeyDown(NativeMethods.VK_V),
            NativeMethods.KeyUp(NativeMethods.VK_V),
            NativeMethods.KeyUp(NativeMethods.VK_CONTROL),
        };
        Send(inputs);
    }

    /// <summary>
    /// Copies the currently selected text by simulating Ctrl+C on the foreground window.
    /// Returns the clipboard text, or null if nothing was copied.
    /// </summary>
    public static async Task<string?> CopySelectedTextAsync()
    {
        // Wait for the user to release the hotkey modifiers
        await WaitForModifierRelease();

        // Save current clipboard content
        string? previousClipboard = null;
        if (Clipboard.ContainsText())
        {
            previousClipboard = Clipboard.GetText();
        }

        // Clear clipboard before simulating copy
        TryClipboard(Clipboard.Clear);

        // Small delay to ensure focus is stable
        await Task.Delay(100);

        string? copiedText = null;

        // Apps like Outlook can be slow to publish the clipboard, so retry the copy
        for (int attempt = 0; attempt < 2 && string.IsNullOrEmpty(copiedText); attempt++)
        {
            uint sequenceBefore = NativeMethods.GetClipboardSequenceNumber();

            // Simulate Ctrl+C
            SimulateCopy();

            // Poll until the clipboard changes (up to ~1.5 seconds)
            for (int i = 0; i < 30; i++)
            {
                await Task.Delay(50);

                if (NativeMethods.GetClipboardSequenceNumber() != sequenceBefore)
                {
                    // Give the source app a moment to finish writing all formats
                    await Task.Delay(50);
                    copiedText = TryGetClipboardText();
                    break;
                }
            }
        }

        // If nothing was copied, restore previous clipboard
        if (string.IsNullOrEmpty(copiedText) && previousClipboard != null)
        {
            TryClipboard(() => Clipboard.SetText(previousClipboard));
        }

        return copiedText;
    }

    /// <summary>
    /// Reads clipboard text, retrying because the clipboard may be briefly locked by another process.
    /// </summary>
    private static string? TryGetClipboardText()
    {
        for (int i = 0; i < 10; i++)
        {
            try
            {
                return Clipboard.ContainsText() ? Clipboard.GetText() : null;
            }
            catch (System.Runtime.InteropServices.ExternalException)
            {
                Thread.Sleep(50);
            }
        }

        return null;
    }

    /// <summary>
    /// Runs a clipboard action, retrying if the clipboard is locked by another process.
    /// </summary>
    private static void TryClipboard(Action action)
    {
        for (int i = 0; i < 10; i++)
        {
            try
            {
                action();
                return;
            }
            catch (System.Runtime.InteropServices.ExternalException)
            {
                Thread.Sleep(50);
            }
        }
    }

    /// <summary>
    /// Pastes the given text by placing it on the clipboard and simulating Ctrl+V.
    /// </summary>
    public static async Task PasteTextAsync(string text)
    {
        // Wait for modifiers to be released (in case user is still holding keys)
        await WaitForModifierRelease();

        Clipboard.SetText(text);

        // Small delay before pasting
        await Task.Delay(50);

        // Simulate Ctrl+V
        SimulatePaste();
    }
}
