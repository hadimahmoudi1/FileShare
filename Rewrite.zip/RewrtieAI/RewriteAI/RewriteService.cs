using Microsoft.SemanticKernel;

namespace RewriteAI;

/// <summary>
/// Uses Semantic Kernel to rewrite text via an LLM.
/// </summary>
internal sealed class RewriteService
{
    private readonly Kernel _kernel;

    private const string RewritePrompt = """
        You are a professional writing assistant. Rewrite the following text to improve clarity, 
        grammar, and readability while preserving the original meaning and tone. 
        Return ONLY the rewritten text with no additional commentary, explanations, or formatting markers.

        Text to rewrite:
        {{$input}}
        """;

    public RewriteService(Kernel kernel)
    {
        _kernel = kernel;
    }

    /// <summary>
    /// Rewrites the given text using the configured LLM.
    /// </summary>
    public async Task<string> RewriteAsync(string text)
    {
        var function = _kernel.CreateFunctionFromPrompt(RewritePrompt);
        var result = await _kernel.InvokeAsync(function, new() { ["input"] = text });
        return result.GetValue<string>()?.Trim() ?? text;
    }
}
