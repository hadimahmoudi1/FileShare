using Microsoft.Extensions.Configuration;
using Microsoft.SemanticKernel;

namespace RewriteAI;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();

        // Load configuration
        var configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        // Read settings
        var endpoint = configuration["AzureOpenAI:Endpoint"];
        var deploymentName = configuration["AzureOpenAI:DeploymentName"];
        var apiKey = configuration["AzureOpenAI:ApiKey"];

        if (IsMissing(endpoint, "YOUR-RESOURCE-NAME") ||
            IsMissing(deploymentName, "YOUR_DEPLOYMENT_NAME") ||
            IsMissing(apiKey, "YOUR_AZURE_OPENAI_KEY_HERE"))
        {
            MessageBox.Show(
                "Azure OpenAI is not configured.\n\n" +
                "Set these values in appsettings.json:\n" +
                "  AzureOpenAI:Endpoint\n" +
                "  AzureOpenAI:DeploymentName\n" +
                "  AzureOpenAI:ApiKey",
                "RewriteAI - Configuration Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            return;
        }

        // Build Semantic Kernel
        var builder = Kernel.CreateBuilder();
        builder.AddAzureOpenAIChatCompletion(deploymentName!, endpoint!, apiKey!);
        var kernel = builder.Build();

        var rewriteService = new RewriteService(kernel);

        Application.Run(new MainForm(rewriteService));
    }

    /// <summary>
    /// True if the setting is empty or still contains its template placeholder.
    /// </summary>
    private static bool IsMissing(string? value, string placeholder) =>
        string.IsNullOrWhiteSpace(value) || value.Contains(placeholder, StringComparison.OrdinalIgnoreCase);
}
