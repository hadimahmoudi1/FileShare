using System;
using System.Collections.Generic;
using System.Text;

namespace BrainGame
{
    class cActivationCode
    {
        /*

        Pre:   None

        Post:   This class generates activation code.
        Assert:

        Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

        Revision History:

        [ 0]  Date:	By:		Version:	Action:
        [ 1]  06/21/06	Hadi	1.000		Initial design.

        */
        int miCodeLength = 6; //Must be an Even Number.
        string msRandomCode;
        string msSecretCode;

        public string RandomCode
        {
            /*
            Pre:   None

            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return msRandomCode;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in RandomCode.Get. " + e.Message);
                }
            }
            set
            {
                try
                {
                    msRandomCode = value;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in RandomCode.try. " + e.Message);
                }

            }
        }

        public string SecretCode
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return msSecretCode;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in SecretCode.Get. " + e.Message);
                }
            }
            set
            {
                try
                {
                    msSecretCode = value;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in SecretCode.Get. " + e.Message);
                }
            }
        }

        private string DecipherCode(string sItem, string sDir)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */

            try
            {
                string sReturn = String.Empty;
                int[,] iaMatrix = 
                                {
                                   //0,1,2,3,4,5,6,7,8,9 
                                    {4,5,6,7,8,9,0,2,3,3},  //0
                                    {2,3,4,5,6,7,8,9,0,1},  //1
                                    {5,3,7,8,9,0,1,2,6,4},  //2
                                    {9,0,1,8,3,4,5,6,7,2},  //3
                                    {7,1,9,0,8,2,3,4,5,6},  //4
                                    {4,5,6,7,0,9,8,1,2,3},  //5
                                    {3,5,4,6,7,8,9,0,1,2},  //6
                                    {8,9,0,1,2,3,4,5,6,7},  //7                
                                    {1,2,3,4,5,6,7,8,9,0},  //8
                                    {6,7,8,9,0,1,2,3,4,5}   //9
                                };
                //      A Clean Set
                //    {0,1,2,3,4,5,6,7,8,9},  //0
                //    {2,3,4,5,6,7,8,9,0,1},  //1
                //    {5,6,7,8,9,0,1,2,3,4},  //2
                //    {9,0,1,2,3,4,5,6,7,8},  //3
                //    {7,8,9,0,1,2,3,4,5,6},  //4
                //    {4,5,6,7,8,9,0,1,2,3},  //5
                //    {3,4,5,6,7,8,9,0,1,2},  //6
                //    {8,9,0,1,2,3,4,5,6,7},  //7                
                //    {1,2,3,4,5,6,7,8,9,0},  //8
                //    {6,7,8,9,0,1,2,3,4,5}   //9
                if (sDir.ToUpper() == "ENCODE")
                {
                    for (int i = 0; i < sItem.Length / 2; i++)
                    {
                        int y = Convert.ToInt32(sItem.Substring(i, 1));
                        int x = Convert.ToInt32(sItem.Substring(i + sItem.Length / 2, 1));
                        sReturn += iaMatrix[x, y].ToString(); ;
                    }
                }
                if (sDir.ToUpper() == "DECODE")
                {

                }

                return sReturn;
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in DecipherCode. " + e.Message);
            }
        }

        private void GenerateCode()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */

            try
            {
                Random R = new Random();
                RandomCode = R.Next((int)System.Math.Pow(10, miCodeLength - 1)
                                    , (int)(System.Math.Pow(10, miCodeLength) - 1)).ToString();
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in GenerateCode. " + e.Message);
            }
        }

        public string GetNewActivationCode()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            
            try
            {
                this.GenerateCode();
                this.SecretCode = this.DecipherCode(this.RandomCode, "ENCODE");
                return this.RandomCode + this.SecretCode;
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in GetNewActivationCode. " + e.Message);
            }
        }

        public bool IsCodeValid(string sItem)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            
            try
            {
                //Is sItem empty, non-numeric or wrong size?
                if (sItem == string.Empty
                    || !IsNumeric(sItem)
                    || sItem.Length != this.miCodeLength + this.miCodeLength / 2)
                {
                    return false;
                }
                else
                {
                    this.RandomCode = sItem.Substring(0, this.miCodeLength);
                    this.SecretCode = this.DecipherCode(this.RandomCode, "ENCODE");
                    if (sItem == RandomCode + SecretCode)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in IsCodeValid. " + e.Message);
            }
        }

        private bool IsNumeric(object value)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            
            try
            {
                int i = Convert.ToInt32(value.ToString());
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }
    }
}
