using System;
using System.Drawing;



namespace BrainGame
{

    public class cPictureNode
    {
        private int mValue;
        private int mMaxVlaue;
        private int mSound;
        private System.Drawing.Color mColor;
        private const int mcMaxValue = 12;
        private Pen oPen = new Pen(System.Drawing.Color.Black);
        private SolidBrush oBlackBrush = new SolidBrush(System.Drawing.Color.Black);
        private int mDisplayValue;
        public ShapeType oNodeShape;

        public cPictureNode()
        {

        }

        public int DisplayValue
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */

            get
            {
                try
                {
                    return mDisplayValue;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in DisplayValue.Get " + e.Message);
                }

            }
            set
            {
                try
                {
                    if (value <= mcMaxValue && value >= 0)
                    {
                        mDisplayValue = value;
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in DisplayValue.Set " + e.Message);
                }

            }
        }

        public int MaxValue
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return mMaxVlaue;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in MaxValue.Get " + e.Message);
                }

            }
            set
            {
                try
                {
                    mMaxVlaue = value;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in MaxValue.Set " + e.Message);
                }

            }
        }

        public int Value
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return mValue;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in Value.Get " + e.Message);
                }

            }
            set
            {
                try
                {
                    if (value <= mcMaxValue && value > 0)
                    {
                        mValue = value;
                        //Set the color once the value is defined.
                        this.Color = this.GetColor(Value);
                    }
                    DisplayValue = Value;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in Value.Set " + e.Message);
                }
            }
        }

        public int Sound
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return mSound;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in Sound.Get " + e.Message);
                }
            }
            set
            {
                try
                {
                    mSound = value;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in Sound.Set " + e.Message);
                }
            }
        }

        public System.Drawing.Color Color
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return this.mColor;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in Color.Get " + e.Message);
                }
            }
            set
            {
                try
                {
                    this.mColor = value;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in Color.Set " + e.Message);
                }
            }
        }

        public void DrawImage(Bitmap b)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (this.oNodeShape == ShapeType.Circle)
                {
                    float iMargine = 10;
                    float iSweepAngle = 360.0F / (float)this.mMaxVlaue;
                    float iStartAngle = this.DisplayValue * iSweepAngle;
                    Graphics g = Graphics.FromImage(b);
                    Pen oPen = new Pen(this.Color);
                    SolidBrush oBrush = new SolidBrush(this.Color);
                    oPen.Width = 0;
                    g.DrawPie(oPen, 0 + iMargine, 0 + iMargine, b.Width - iMargine * 2, b.Height - iMargine * 2, iStartAngle, iSweepAngle);
                    g.FillPie(oBrush, 0 + iMargine, 0 + iMargine, b.Width - iMargine * 2, b.Height - iMargine * 2, iStartAngle, iSweepAngle);

                    g.DrawPie(oPen, b.Width / 2 - 10, b.Height / 2 - 10, 20, 20, 0, 360);
                    g.FillPie(oBlackBrush, b.Width / 2 - 10, b.Height / 2 - 10, 20, 20, 0, 360);

                    g.Dispose();
                }
                if (this.oNodeShape == ShapeType.Rectangle)
                {

                    Graphics g = Graphics.FromImage(b);
                    Pen oPen = new Pen(this.Color);
                    SolidBrush oBrush = new SolidBrush(this.Color);
                    oPen.Width = 1;
                    if ((this.mMaxVlaue % 2) == 0) //IF Even
                    {
                        int iDeltaY = b.Height / this.mMaxVlaue * 2;
                        int iDeltaX = b.Width / 2;
                        int iY = (int)((this.DisplayValue - 1) / 2) * iDeltaY;
                        int iX = (this.DisplayValue % 2) * iDeltaX;

                        g.DrawRectangle(oPen, iX, iY, iDeltaX, iDeltaY);
                        g.FillRectangle(oBrush, iX, iY, iDeltaX, iDeltaY);
                    }
                    else //If odd
                    {
                        int iDeltaY = b.Height / this.mMaxVlaue;
                        int iY = (this.DisplayValue - 1) * iDeltaY;
                        g.DrawRectangle(oPen, 0, iY, b.Width, iDeltaY);
                        g.FillRectangle(oBrush, 0, iY, b.Width, iDeltaY);
                    }
                    g.Dispose();
                }
                if (this.oNodeShape == ShapeType.CarvedTriangle)
                {
                    float tension;
                    float iSweepAngle = 360 / (float)this.mMaxVlaue;
                    float iStartAngle = this.DisplayValue * iSweepAngle;
                    float iRadious = 100;
                    float iLowRadious = 20;

                    Graphics g = Graphics.FromImage(b);
                    Pen oPen = new Pen(this.Color);
                    SolidBrush oBrush = new SolidBrush(this.Color);
                    oPen.Width = 2;
                    int iCenterX = b.Width / 2;
                    int iCenterY = b.Height / 2;
                    Point point1 = new Point(iCenterX + (int)(iRadious * Math.Cos(iStartAngle)), iCenterY + (int)(iRadious * Math.Sin(iStartAngle)));
                    Point point2 = new Point(iCenterX + (int)(iRadious * Math.Cos(iStartAngle + iSweepAngle)), iCenterY + (int)(iRadious * Math.Sin(iStartAngle + iSweepAngle)));
                    Point point3 = new Point(iCenterX + (int)(iLowRadious * Math.Cos(iStartAngle + 80)), iCenterY + (int)(iLowRadious * Math.Sin(iStartAngle + 80)));
                    Point[] aCurvePoints = { point1, point2, point3 };

                    if (this.mMaxVlaue == 6)
                    {
                        tension = 21.0F;
                    }
                    else
                    {
                        tension = -1.0F;
                    }

                    System.Drawing.Drawing2D.FillMode aFillMode = System.Drawing.Drawing2D.FillMode.Alternate;
                    // Draw closed curve to screen.
                    g.DrawClosedCurve(oPen, aCurvePoints, tension, aFillMode);
                    g.FillClosedCurve(oBrush, aCurvePoints, aFillMode, tension);
                    g.Dispose();
                }
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in DrawImage. " + e.Message);
            }

        }

        public void Show(Bitmap b)
        {
            /*

            Pre:   None

            Post:	It makes the item color Black.
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  05/17/06	Hadi	1.000		Initial design.

            */

            try
            {
                if (this.oNodeShape == ShapeType.Circle)
                {
                    float iMargine = 10;
                    float iSweepAngle = 360.0F / (float)this.mMaxVlaue;
                    float iStartAngle = this.DisplayValue * iSweepAngle;
                    Graphics g = Graphics.FromImage(b);
                    Pen oPen = new Pen(this.GetColorShow(this.Value));
                    SolidBrush oBrush = new SolidBrush(this.GetColorShow(this.Value));
                    oPen.Width = 1;
                    g.DrawPie(oPen, 0 + iMargine, 0 + iMargine, b.Width - iMargine * 2, b.Height - iMargine * 2, iStartAngle, iSweepAngle);
                    g.FillPie(oBrush, 0 + iMargine, 0 + iMargine, b.Width - iMargine * 2, b.Height - iMargine * 2, iStartAngle, iSweepAngle);

                    g.Dispose();
                }
                if (this.oNodeShape == ShapeType.Rectangle)
                {
                    Graphics g = Graphics.FromImage(b);
                    Pen oPen = new Pen(this.GetColorShow(this.Value));
                    SolidBrush oBrush = new SolidBrush(this.GetColorShow(this.Value));
                    oPen.Width = 1;
                    if ((this.mMaxVlaue % 2) == 0) //IF Even
                    {
                        int iDeltaY = b.Height / this.mMaxVlaue * 2;
                        int iDeltaX = b.Width / 2;
                        int iY = (int)((this.DisplayValue - 1) / 2) * iDeltaY;
                        int iX = (this.DisplayValue % 2) * iDeltaX;

                        g.DrawRectangle(oPen, iX, iY, iDeltaX, iDeltaY);
                        g.FillRectangle(oBrush, iX, iY, iDeltaX, iDeltaY);
                    }
                    else //If odd
                    {
                        int iDeltaY = b.Height / this.mMaxVlaue;
                        int iY = (this.DisplayValue - 1) * iDeltaY;
                        g.DrawRectangle(oPen, 0, iY, b.Width, iDeltaY);
                        g.FillRectangle(oBrush, 0, iY, b.Width, iDeltaY);
                    }
                    g.Dispose();
                }
                if (this.oNodeShape == ShapeType.CarvedTriangle)
                {
                    float tension;
                    float iSweepAngle = 360 / (float)this.mMaxVlaue;
                    float iStartAngle = this.DisplayValue * iSweepAngle;
                    float iRadious = 100;
                    float iLowRadious = 20;

                    Graphics g = Graphics.FromImage(b);
                    Pen oPen = new Pen(this.GetColorShow(this.Value));
                    SolidBrush oBrush = new SolidBrush(this.GetColorShow(this.Value));
                    oPen.Width = 2;
                    int iCenterX = b.Width / 2;
                    int iCenterY = b.Height / 2;
                    Point point1 = new Point(iCenterX + (int)(iRadious * Math.Cos(iStartAngle)), iCenterY + (int)(iRadious * Math.Sin(iStartAngle)));
                    Point point2 = new Point(iCenterX + (int)(iRadious * Math.Cos(iStartAngle + iSweepAngle)), iCenterY + (int)(iRadious * Math.Sin(iStartAngle + iSweepAngle)));
                    Point point3 = new Point(iCenterX + (int)(iLowRadious * Math.Cos(iStartAngle + 80)), iCenterY + (int)(iLowRadious * Math.Sin(iStartAngle + 80)));
                    Point[] aCurvePoints = { point1, point2, point3 };

                    if (this.mMaxVlaue == 6)
                    {
                        tension = 21.0F;
                    }
                    else
                    {
                        tension = -1.0F;
                    }

                    System.Drawing.Drawing2D.FillMode aFillMode = System.Drawing.Drawing2D.FillMode.Alternate;
                    // Draw closed curve to screen.
                    g.DrawClosedCurve(oPen, aCurvePoints, tension, aFillMode);
                    g.FillClosedCurve(oBrush, aCurvePoints, aFillMode, tension);
                    g.Dispose();
                }
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in Show. " + e.Message);
            }
        }

        private System.Drawing.Color GetColor(int iItem)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (this.mColor.IsEmpty)
                {
                    switch (iItem)
                    {
                        case 1:
                            return System.Drawing.Color.Blue;
                        case 2:
                            return System.Drawing.Color.Yellow;
                        case 3:
                            return System.Drawing.Color.Red;
                        case 4:
                            return System.Drawing.Color.Green;
                        case 5:
                            return System.Drawing.Color.Pink;
                        case 6:
                            return System.Drawing.Color.DarkOrange;
                        case 7:
                            return System.Drawing.Color.Gray;
                        case 8:
                            return System.Drawing.Color.LawnGreen;
                        case 9:
                            return System.Drawing.Color.WhiteSmoke;
                        case 10:
                            return System.Drawing.Color.Brown;
                        case 11:
                            return System.Drawing.Color.DarkSalmon;
                        case 12:
                            return System.Drawing.Color.YellowGreen;
                        default:
                            return System.Drawing.Color.Black;
                    }
                }
                else
                {
                    return this.mColor;
                }
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in GetColor. " + e.Message);
            }

        }

        private System.Drawing.Color GetColorShow(int iItem)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                return System.Drawing.Color.Black;
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in GetColorShow. " + e.Message);
            }
        }
    }
}
