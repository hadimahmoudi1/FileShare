/*

Pre:   None

Post:	Guess Nodes
Assert:

Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

Revision History:

[ 0]  Date:		By:		Version:	Action:
[ 1]  03/25/04	Hadi	1.000		Initial design.

*/

using System;


namespace BrainGame
{
    public class cGuessNode : iGuessNodes
    {
        private int mValue;
        private int mMaxVlaue;
        static Random R = new Random();
        private const int mcMaxValue = 12;

        public cGuessNode()
        {

        }

        public int MaxValue
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */            
            get
            {
                try
                {
                    return mMaxVlaue;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in MaxValue.Get. " + e.Message);
                }

            }
            set
            {
                try
                {
                    mMaxVlaue = value;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in MaxValue.Set. " + e.Message);
                }

            }
        }

        public int Value
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return mValue;
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in Value.Get. " + e.Message);
                }

            }
            set
            {
                try
                {
                    if (value <= mcMaxValue && value >= 0)
                    {
                        mValue = value;
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Error: Error in Value.Set. " + e.Message);
                }

            }
        }

        public void Randomize()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                Value = R.Next(0, MaxValue);
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in Randomize. " + e.Message);
            }

        }

        public bool IsRight(int item)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (item == Value)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in . " + e.Message);
            }
        }

    }
}
