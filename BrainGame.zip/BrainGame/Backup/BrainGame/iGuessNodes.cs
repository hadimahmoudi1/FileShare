/*

Pre:   None

Post:	Interface for all type of Guess nodes.
Assert:

Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

Revision History:

[ 0]  Date:		By:		Version:	Action:
[ 1]  03/25/04	Hadi	1.000		Initial design.

*/
using System;

namespace BrainGame
{
	
	interface iGuessNodes
	{
		int MaxValue { get; set;}	//Shared among all nodes
        int Value { get; set;}		//Actual value or position of the file.
        void Randomize();			//Sets the Value property.
        bool IsRight(int item);
	}
}
