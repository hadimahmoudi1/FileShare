namespace BrainGame
{
    partial class frmOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOptions));
            this.cmdOk = new System.Windows.Forms.Button();
            this.frmLevels = new System.Windows.Forms.GroupBox();
            this.cboMaxGuess = new System.Windows.Forms.ComboBox();
            this.lblMAxOptions = new System.Windows.Forms.Label();
            this.lblMaxGuess = new System.Windows.Forms.Label();
            this.cboMaxOptions = new System.Windows.Forms.ComboBox();
            this.frmReposition = new System.Windows.Forms.GroupBox();
            this.chkRepositionAfter = new System.Windows.Forms.CheckBox();
            this.cmbRepositionIteration = new System.Windows.Forms.ComboBox();
            this.cmdCancle = new System.Windows.Forms.Button();
            this.frmShape = new System.Windows.Forms.GroupBox();
            this.optCarvedTriangle = new System.Windows.Forms.RadioButton();
            this.optSquare = new System.Windows.Forms.RadioButton();
            this.optCircle = new System.Windows.Forms.RadioButton();
            this.chkSound = new System.Windows.Forms.CheckBox();
            this.chkReverseOrder = new System.Windows.Forms.CheckBox();
            this.frmLevels.SuspendLayout();
            this.frmReposition.SuspendLayout();
            this.frmShape.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdOk
            // 
            this.cmdOk.Location = new System.Drawing.Point(9, 190);
            this.cmdOk.Name = "cmdOk";
            this.cmdOk.Size = new System.Drawing.Size(140, 23);
            this.cmdOk.TabIndex = 8;
            this.cmdOk.Text = "&OK";
            this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
            // 
            // frmLevels
            // 
            this.frmLevels.Controls.Add(this.cboMaxGuess);
            this.frmLevels.Controls.Add(this.lblMAxOptions);
            this.frmLevels.Controls.Add(this.lblMaxGuess);
            this.frmLevels.Controls.Add(this.cboMaxOptions);
            this.frmLevels.Location = new System.Drawing.Point(94, 12);
            this.frmLevels.Name = "frmLevels";
            this.frmLevels.Size = new System.Drawing.Size(148, 69);
            this.frmLevels.TabIndex = 10;
            this.frmLevels.TabStop = false;
            this.frmLevels.Text = "Levels";
            // 
            // cboMaxGuess
            // 
            this.cboMaxGuess.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "30",
            "35",
            "40",
            "45",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100",
            ""});
            this.cboMaxGuess.Location = new System.Drawing.Point(69, 42);
            this.cboMaxGuess.Name = "cboMaxGuess";
            this.cboMaxGuess.Size = new System.Drawing.Size(40, 21);
            this.cboMaxGuess.TabIndex = 3;
            this.cboMaxGuess.Text = "15";
            // 
            // lblMAxOptions
            // 
            this.lblMAxOptions.Location = new System.Drawing.Point(8, 18);
            this.lblMAxOptions.Name = "lblMAxOptions";
            this.lblMAxOptions.Size = new System.Drawing.Size(55, 18);
            this.lblMAxOptions.TabIndex = 4;
            this.lblMAxOptions.Text = "Nodes:";
            // 
            // lblMaxGuess
            // 
            this.lblMaxGuess.Location = new System.Drawing.Point(8, 42);
            this.lblMaxGuess.Name = "lblMaxGuess";
            this.lblMaxGuess.Size = new System.Drawing.Size(55, 15);
            this.lblMaxGuess.TabIndex = 3;
            this.lblMaxGuess.Text = "Levels:";
            // 
            // cboMaxOptions
            // 
            this.cboMaxOptions.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cboMaxOptions.Location = new System.Drawing.Point(69, 18);
            this.cboMaxOptions.Name = "cboMaxOptions";
            this.cboMaxOptions.Size = new System.Drawing.Size(40, 21);
            this.cboMaxOptions.TabIndex = 2;
            this.cboMaxOptions.Text = "4";
            // 
            // frmReposition
            // 
            this.frmReposition.Controls.Add(this.chkRepositionAfter);
            this.frmReposition.Controls.Add(this.cmbRepositionIteration);
            this.frmReposition.Location = new System.Drawing.Point(9, 112);
            this.frmReposition.Name = "frmReposition";
            this.frmReposition.Size = new System.Drawing.Size(237, 72);
            this.frmReposition.TabIndex = 13;
            this.frmReposition.TabStop = false;
            this.frmReposition.Text = "Repositions";
            // 
            // chkRepositionAfter
            // 
            this.chkRepositionAfter.AutoSize = true;
            this.chkRepositionAfter.Location = new System.Drawing.Point(7, 47);
            this.chkRepositionAfter.Name = "chkRepositionAfter";
            this.chkRepositionAfter.Size = new System.Drawing.Size(226, 17);
            this.chkRepositionAfter.TabIndex = 7;
            this.chkRepositionAfter.Text = "Reposition &after sequence shown (harder).";
            this.chkRepositionAfter.UseVisualStyleBackColor = true;
            // 
            // cmbRepositionIteration
            // 
            this.cmbRepositionIteration.Items.AddRange(new object[] {
            "Do not re-position colors",
            "Re-positionon every 1 run",
            "Re-position on every 2 runs",
            "Re-position on every 3 runs",
            "Re-position on every 4 runs",
            "Re-position on every 5 runs"});
            this.cmbRepositionIteration.Location = new System.Drawing.Point(3, 19);
            this.cmbRepositionIteration.Name = "cmbRepositionIteration";
            this.cmbRepositionIteration.Size = new System.Drawing.Size(175, 21);
            this.cmbRepositionIteration.TabIndex = 6;
            this.cmbRepositionIteration.Text = "Do not re-position nodes.";
            // 
            // cmdCancle
            // 
            this.cmdCancle.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancle.Location = new System.Drawing.Point(155, 190);
            this.cmdCancle.Name = "cmdCancle";
            this.cmdCancle.Size = new System.Drawing.Size(87, 23);
            this.cmdCancle.TabIndex = 9;
            this.cmdCancle.Text = "&Cancle";
            this.cmdCancle.Click += new System.EventHandler(this.cmdCancle_Click);
            // 
            // frmShape
            // 
            this.frmShape.Controls.Add(this.optCarvedTriangle);
            this.frmShape.Controls.Add(this.optSquare);
            this.frmShape.Controls.Add(this.optCircle);
            this.frmShape.Location = new System.Drawing.Point(4, 9);
            this.frmShape.Name = "frmShape";
            this.frmShape.Size = new System.Drawing.Size(72, 92);
            this.frmShape.TabIndex = 1;
            this.frmShape.TabStop = false;
            this.frmShape.Text = "Shapes";
            // 
            // optCarvedTriangle
            // 
            this.optCarvedTriangle.Location = new System.Drawing.Point(8, 64);
            this.optCarvedTriangle.Name = "optCarvedTriangle";
            this.optCarvedTriangle.Size = new System.Drawing.Size(59, 16);
            this.optCarvedTriangle.TabIndex = 2;
            this.optCarvedTriangle.Text = "Cur&ve";
            // 
            // optSquare
            // 
            this.optSquare.Location = new System.Drawing.Point(8, 40);
            this.optSquare.Name = "optSquare";
            this.optSquare.Size = new System.Drawing.Size(59, 18);
            this.optSquare.TabIndex = 1;
            this.optSquare.TabStop = true;
            this.optSquare.Text = "S&quare";
            // 
            // optCircle
            // 
            this.optCircle.Location = new System.Drawing.Point(8, 16);
            this.optCircle.Name = "optCircle";
            this.optCircle.Size = new System.Drawing.Size(59, 16);
            this.optCircle.TabIndex = 0;
            this.optCircle.Text = "&Circle";
            // 
            // chkSound
            // 
            this.chkSound.Checked = true;
            this.chkSound.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSound.Location = new System.Drawing.Point(94, 87);
            this.chkSound.Name = "chkSound";
            this.chkSound.Size = new System.Drawing.Size(64, 24);
            this.chkSound.TabIndex = 4;
            this.chkSound.Text = "&Sound";
            // 
            // chkReverseOrder
            // 
            this.chkReverseOrder.AutoSize = true;
            this.chkReverseOrder.Location = new System.Drawing.Point(176, 89);
            this.chkReverseOrder.Name = "chkReverseOrder";
            this.chkReverseOrder.Size = new System.Drawing.Size(66, 17);
            this.chkReverseOrder.TabIndex = 5;
            this.chkReverseOrder.Text = "&Reverse";
            this.chkReverseOrder.UseVisualStyleBackColor = true;
            // 
            // frmOptions
            // 
            this.AcceptButton = this.cmdOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cmdCancle;
            this.ClientSize = new System.Drawing.Size(254, 233);
            this.Controls.Add(this.chkReverseOrder);
            this.Controls.Add(this.cmdOk);
            this.Controls.Add(this.frmLevels);
            this.Controls.Add(this.frmReposition);
            this.Controls.Add(this.cmdCancle);
            this.Controls.Add(this.frmShape);
            this.Controls.Add(this.chkSound);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmOptions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmOptions";
            this.Load += new System.EventHandler(this.frmOptions_Load);
            this.frmLevels.ResumeLayout(false);
            this.frmReposition.ResumeLayout(false);
            this.frmReposition.PerformLayout();
            this.frmShape.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdOk;
        private System.Windows.Forms.GroupBox frmLevels;
        private System.Windows.Forms.ComboBox cboMaxGuess;
        private System.Windows.Forms.Label lblMAxOptions;
        private System.Windows.Forms.Label lblMaxGuess;
        private System.Windows.Forms.ComboBox cboMaxOptions;
        private System.Windows.Forms.GroupBox frmReposition;
        private System.Windows.Forms.ComboBox cmbRepositionIteration;
        private System.Windows.Forms.Button cmdCancle;
        private System.Windows.Forms.GroupBox frmShape;
        private System.Windows.Forms.RadioButton optCarvedTriangle;
        private System.Windows.Forms.RadioButton optSquare;
        private System.Windows.Forms.RadioButton optCircle;
        private System.Windows.Forms.CheckBox chkSound;
        private System.Windows.Forms.CheckBox chkRepositionAfter;
        private System.Windows.Forms.CheckBox chkReverseOrder;
    }
}