/*
Pre:   None
Post:
Assert:

Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

Revision History:

[ 0]  Date:	By:		Version:	Action:
[ 1]  07/26/06	Hadi	1.000		Initial design.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BrainGame
{
    public partial class frmInputBox : Form
    {
        string formCaption = string.Empty;
        string formPrompt = string.Empty;
        string inputResponse = string.Empty;
        string defaultValue = string.Empty;

        public string FormCaption
        {
            get { return formCaption; }
            set { formCaption = value; }
        }
        public string FormPrompt
        {
            get { return formPrompt; }
            set { formPrompt = value; }
        }
        public string InputResponse
        {
            get { return inputResponse; }
            set { inputResponse = value; }
        }
        public string DefaultValue
        {
            get { return defaultValue; }
            set { defaultValue = value; }
        }


        public frmInputBox()
        {
            InitializeComponent();
        }

        private void frmInputBox_Load(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.Text = cPublicObjects.sProductName;
                this.txtInput.Text = defaultValue;
                this.lblPrompt.Text = formPrompt;
                this.Text = formCaption;
                this.txtInput.SelectionStart = 0;
                this.txtInput.SelectionLength = this.txtInput.Text.Length;
                this.txtInput.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in frmInputBox_Load." + ex.Message);
            }
        }

        private void cmdOk_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                InputResponse = this.txtInput.Text;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in cmdOk_Click." + ex.Message);
            }
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in cmdCancel_Click." + ex.Message);
            }
        }
    }
}