using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Configuration;


namespace BrainGame
{
    public partial class frmBrainGame : Form
    {

        // Application Variables
        private bool mbGameRuns;
        private int miDelay;
        public int mMaxGuess;
        private int maxOptions;
        private int mGuessLevel;
        private int mGuessCurrent;
        private Bitmap mBitmap;
        private cPictureNode[] mPictureNodes;
        private cGuessNode[] mGuessNodes;
        static Random R = new Random();


        public frmBrainGame()
        {
            InitializeComponent();
        }

        private void RepositionNodes()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                System.Threading.Thread.Sleep(100);
                for (int i = maxOptions - 1; i > -1; i--)
                {
                    int j = R.Next(0, i);
                    //SWAP DisplayValue
                    int iTemp = mPictureNodes[i].DisplayValue;
                    mPictureNodes[i].DisplayValue = mPictureNodes[j].DisplayValue;
                    mPictureNodes[j].DisplayValue = iTemp;
                }
                this.DrawPictureNodes();
                this.picMain.Refresh();
                System.Threading.Thread.Sleep(700);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in RepositionNodes." + ex.Message);
            }
        }

        private void StartSequance()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (cPublicObjects.Settings.Reposition > 0 && (this.mGuessLevel % cPublicObjects.Settings.Reposition == 0) && this.mGuessLevel != 0 && !cPublicObjects.Settings.RepositionAfterSequence)
                {

                    RepositionNodes();

                }
                for (int i = 0; i <= this.mGuessLevel && this.mGuessLevel < this.mMaxGuess; i++)
                {
                    Demo(this.mGuessNodes[i].Value);
                }
                if (cPublicObjects.Settings.Reposition > 0 && (this.mGuessLevel % cPublicObjects.Settings.Reposition == 0) && this.mGuessLevel != 0 && cPublicObjects.Settings.RepositionAfterSequence)
                {
                    RepositionNodes();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in StartSequance." + ex.Message);
            }
        }

        private void DemoToShowMistake(int Item)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                const int iDelay = 100;
                if (Item > -1)
                {
                    //First turn all off.
                    for (int i = 0; i < maxOptions; i++)
                    {
                        mPictureNodes[i].Show(this.mBitmap);    //Hide!
                    }
                    this.picMain.Refresh();

                    //Demo the right one.
                    for (int i = 1; i < 8; i++)
                    {
                        this.mPictureNodes[Item].Show(this.mBitmap);
                        this.picMain.Refresh();
                        if (cPublicObjects.Settings.Sound)
                        {
                            System.Threading.Thread.Sleep(iDelay);
                        }
                        else
                        //No Beep But show the delay.
                        {
                            System.Threading.Thread.Sleep(iDelay);
                        }
                        this.mPictureNodes[Item].DrawImage(this.mBitmap);
                        this.picMain.Refresh();
                        System.Threading.Thread.Sleep(iDelay);
                    }

                    // Draw the images again.
                    for (int i = 0; i < maxOptions; i++)
                    {
                        mPictureNodes[i].DrawImage(this.mBitmap);    //Show     
                    }
                    this.picMain.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in DemoToShowMistake." + ex.Message);
            }
        }
        
        private void Demo(int Item)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (Item > -1)
                {
                    this.mPictureNodes[Item].Show(this.mBitmap);
                    this.picMain.Refresh();
                    if (cPublicObjects.Settings.Sound)
                    {
                        cWSound.Play("beep" + this.mPictureNodes[Item].Sound.ToString() + ".wav", cWSound.SND_ASYNC);
                        System.Threading.Thread.Sleep(miDelay);
                    }
                    else
                    //No Beep But show the delay.
                    {
                        System.Threading.Thread.Sleep(miDelay);
                    }
                    this.mPictureNodes[Item].DrawImage(this.mBitmap);
                    this.picMain.Refresh();
                    System.Threading.Thread.Sleep(100);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in Demo." + ex.Message);
            }
        }
        
        private void IncreaseSpeed(int Item)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (miDelay >= 300 && Item >= 5)
                {
                    miDelay = 200;
                }
                else
                {
                    if (miDelay >= 200 && Item >= 10)
                    {
                        miDelay = 100;
                    }
                    else
                    {
                        if (miDelay >= 100 && Item >= 15)
                        {
                            miDelay = 50;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in IncreaseSpeed." + ex.Message);
            }
        }
        
        private void EndGameAnnoucment()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.mbGameRuns = false;
                this.TimMain.Stop();
                if (cPublicObjects.Settings.Sound)
                {
                    cWSound.Play("EndGame.wav", cWSound.SND_ASYNC);
                }
                if (cPublicObjects.Settings.CustomReverseOrder && cPublicObjects.Settings.GameLevel == "C")
                {
                    DemoToShowMistake(this.mGuessNodes[this.mGuessLevel - this.mGuessCurrent].Value);
                }
                else
                {
                    DemoToShowMistake(this.mGuessNodes[this.mGuessCurrent].Value);
                }

                this.stbMain.Text = "Game over...";
                UpdateScore();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in EndGameAnnoucment." + ex.Message);
            }
        }

        private void UpdateScore()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (cPublicObjects.Settings.GameLevel == "B" && cPublicObjects.Settings.ScoreBeginner < this.mGuessLevel)
                {
                    string sName = cPublicObjects.InputBox("Congradulations, you got the highest score \nfor biginner level.\nPlease enter your name?", "Enter your name", "");
                    if (sName != string.Empty)
                    {
                        cPublicObjects.Settings.BeginnerUserName = sName;
                        cPublicObjects.Settings.ScoreBeginner = this.mGuessLevel;
                        cPublicObjects.Settings.Save();
                    }
                }
                if (cPublicObjects.Settings.GameLevel == "I" && cPublicObjects.Settings.ScoreIntermediate < this.mGuessLevel)
                {
                    string sName = cPublicObjects.InputBox("Congradulations, you got the highest score \nfor intermediate level.\nPlease enter your name?", "Enter your name", "");
                    if (sName != string.Empty)
                    {
                        cPublicObjects.Settings.IntermediateUserName = sName;
                        cPublicObjects.Settings.ScoreIntermediate = this.mGuessLevel;
                        cPublicObjects.Settings.Save();
                    }
                }
                if (cPublicObjects.Settings.GameLevel == "E" && cPublicObjects.Settings.ScoreExpert < this.mGuessLevel)
                {
                    string sName = cPublicObjects.InputBox("Congradulations, you got the highest score \nfor expert level.\nPlease enter your name?", "Enter your name", "");
                    if (sName != string.Empty)
                    {
                        cPublicObjects.Settings.ExpertUserName = sName;
                        cPublicObjects.Settings.ScoreExpert = this.mGuessLevel;
                        cPublicObjects.Settings.Save();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in UpdateScore." + ex.Message);
            }

        }
        
        private void WinGameAnnoucment()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.mbGameRuns = false;
                this.TimMain.Stop();
                if (cPublicObjects.Settings.Sound)
                {
                    cWSound.Play("Win.wav", cWSound.SND_ASYNC);
                }
                UpdateScore();
                this.stbMain.Text = "Congradulations...";
                ClearRedrawPictures(true);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in WinGameAnnoucment." + ex.Message);
            }
        }
        
        private void DrawPictureNodes()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                for (int i = 0; i < maxOptions; i++)
                {
                    mPictureNodes[i].DrawImage(this.mBitmap);
                    this.picMain.Image = this.mBitmap;
                    this.picMain.Refresh();
                    System.Threading.Thread.Sleep(100);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in DrawPictureNodes." + ex.Message);
            }
        }
        
        private void InitializePictureNodes()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                mPictureNodes = new cPictureNode[maxOptions];

                Random R = new Random();
                int SoundShift = R.Next(0, 11);
                //int iSoundRandom = cPictureNod

                for (int i = 0; i < maxOptions; i++)
                {
                    mPictureNodes[i] = new cPictureNode();
                    mPictureNodes[i].oNodeShape = (ShapeType)cPublicObjects.Settings.SelectShape;
                    mPictureNodes[i].MaxValue = maxOptions;
                    mPictureNodes[i].Sound = SoundShift + i + 1;
                    mPictureNodes[i].Value = i + 1;
                    mPictureNodes[i].DisplayValue = i + 1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in InitializePictureNodes." + ex.Message);
            }
        }
        
        private void RandomizeNodes()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                for (int i = 0; i < mMaxGuess; i++)
                {
                    mGuessNodes[i].Randomize();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in RandomizeNodes." + ex.Message);
            }
        }
        
        private void InitializeGuessNodes()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                mGuessNodes = new cGuessNode[mMaxGuess];

                for (int i = 0; i < mMaxGuess; i++)
                {
                    mGuessNodes[i] = new cGuessNode();
                    mGuessNodes[i].MaxValue = maxOptions;
                    mGuessNodes[i].Randomize();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in InitializeGuessNodes." + ex.Message);
            }
        }
        
        private int GetValueByColor(Color pixelColor)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                for (int i = 0; i < this.maxOptions; i++)
                {
                    if (
                        (pixelColor.R == this.mPictureNodes[i].Color.R)
                        && (pixelColor.G == this.mPictureNodes[i].Color.G)
                        && (pixelColor.B == this.mPictureNodes[i].Color.B))
                    {
                        return i;
                    }
                }
                //Did not find.
                return -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in GetValueByColor." + ex.Message);
                return -1;
            }
        }
        
        private void LoadConfigeration()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (cPublicObjects.Settings.MaxOption < 2 || cPublicObjects.Settings.MaxOption > 12)
                {
                    cPublicObjects.Settings.MaxOption = 4;
                    maxOptions = 4;
                }
                else
                {
                    maxOptions = cPublicObjects.Settings.MaxOption;
                }
                if (cPublicObjects.Settings.MaxGuess < 2 || cPublicObjects.Settings.MaxOption > 20)
                {
                    cPublicObjects.Settings.MaxGuess = 20;
                    mMaxGuess = 20;
                }
                else
                {
                    mMaxGuess = cPublicObjects.Settings.MaxGuess;
                }

                this.pbrStatus.Maximum = mMaxGuess;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in LoadConfigeration." + ex.Message);
            }
        }
        
        private void ResetPictureDisplayValue()
        {
            /*
            Pre:   None

            Post:   Set the DisplayOrder of the picture to original value. DisplayOrder = Value.
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  05/18/06	Hadi	1.000		Initial design.
            */
            try
            {
                for (int i = 0; i < maxOptions; i++)
                {
                    mPictureNodes[i].DisplayValue = i + 1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in ResetPictureDisplayValue." + ex.Message);
            }
        }
        
        private void CleanPictureBox()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                Graphics g = Graphics.FromImage(picMain.Image);
                SolidBrush oBrush = new SolidBrush(System.Drawing.Color.Black);
                g.FillRectangle(oBrush, 0, 0, picMain.Width, picMain.Height);
                g.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in CleanPictureBox." + ex.Message);
            }
        }

        private void ClearRedrawPictures(bool bWait)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                CleanPictureBox(); //Clean bitmap
                if (bWait)
                {
                    System.Threading.Thread.Sleep(200);
                }
                this.TimMain.Stop();
                LoadConfigeration();
                InitializePictureNodes();
                InitializeGuessNodes();
                RandomizeNodes();
                mGuessLevel = 0;
                miDelay = 300;
                this.pbrStatus.Value = mGuessLevel;
                mGuessCurrent = 0;
                ResetPictureDisplayValue();
                DrawPictureNodes();
                if (bWait)
                {
                    System.Threading.Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in ClearRedrawPictures." + ex.Message);
            }
        }
        
        private void cmdStart_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (cPublicObjects.Settings.Sound)
                {
                    cWSound.Play("start.wav", cWSound.SND_ASYNC);
                }
                this.stbMain.Text = "";
                ClearRedrawPictures(true);
                StartSequance();
                this.TimMain.Start();
                this.mbGameRuns = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in cmdStart_Click." + ex.Message);
            }
        }

        private bool IsClickRight(int ClickValue)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                //Do we need to proceed in reverseorder.
                if (cPublicObjects.Settings.CustomReverseOrder && cPublicObjects.Settings.GameLevel == "C")
                {
                    return (this.mGuessNodes[this.mGuessLevel - this.mGuessCurrent].IsRight(ClickValue));
                }
                else //Do not proceed in reverseorder.
                {
                    return (this.mGuessNodes[this.mGuessCurrent].IsRight(ClickValue));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in IsClickRight." + ex.Message);
                return false;
            }
        }
        
        private void picMain_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (mbGameRuns)
                {
                    int ClickValue = -1;
                    this.picMain.Image = this.mBitmap;
                    Color pixelColor = this.mBitmap.GetPixel(e.X, e.Y);
                    ClickValue = GetValueByColor(pixelColor);
                    Demo(ClickValue);
                    if (IsClickRight(ClickValue))//We need to know if things are in reverseorder or not!
                    {
                        //Are we in evaluation mode. If so quit after 5 iteration.
                        if (cPublicObjects.bIsDemo && this.mGuessCurrent >= 4)
                        {
                            MessageBox.Show("The evaluation version is limited to 5 iterations.");
                            this.TimMain.Stop(); //Need to stop so we do not see Demo on right node.
                            this.mGuessLevel = this.mGuessCurrent;
                            this.mMaxGuess = this.mGuessCurrent + 1;
                        }


                        //IF we still need to go to get to the end of sequance.
                        if (this.mGuessCurrent < this.mGuessLevel)
                        {
                            this.TimMain.Stop();
                            this.TimMain.Start();
                        }
                        //IF we get to the end of sequance and we are not done.
                        if (this.mGuessCurrent == this.mGuessLevel && this.mGuessCurrent != this.mMaxGuess - 1)
                        {
                            mGuessCurrent++; //Only to show by ShowProgressOnStatusbar
                            ShowProgressOnStatusbar();
                            this.TimMain.Stop();
                            System.Threading.Thread.Sleep(500);	//Make a delay at the end of sequance.
                            mGuessLevel++;
                            mGuessCurrent = -1; //-1 because we are going to increment it by 1 so  = 0 
                            StartSequance();
                            this.TimMain.Start();
                            this.pbrStatus.Value = this.mGuessLevel;
                        }

                        if (this.mGuessCurrent == this.mGuessLevel && this.mGuessCurrent == this.mMaxGuess - 1)
                        {
                            mGuessLevel++;
                            this.pbrStatus.Value = this.mGuessLevel;
                            this.WinGameAnnoucment();
                        }
                        //Increment to the next guess.

                        this.mGuessCurrent++;
                        IncreaseSpeed(mGuessCurrent);
                        ShowProgressOnStatusbar();
                    }
                    else
                    {
                        //User made a mistake.
                        EndGameAnnoucment();
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in picMain_MouseDown." + ex.Message);
            }
        }

        private void SetMenuCheckMark()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.mnuBeginner.Checked = false;
                this.mnuIntermediate.Checked = false;
                this.mnuExpert.Checked = false;
                this.mnuOptions.Checked = false;
                switch (cPublicObjects.Settings.GameLevel)
                {
                    case "B":
                        this.mnuBeginner.Checked = true;
                        break;
                    case "I":
                        this.mnuIntermediate.Checked = true;
                        break;
                    case "E":
                        this.mnuExpert.Checked = true;
                        break;
                    case "C":
                        this.mnuOptions.Checked = true;
                        break;
                    default:
                        Console.WriteLine("Error in SetMenuCheckMark!");
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in SetMenuCheckMark." + ex.Message);
            }
        }
        
        private void frmBrainGame_Load(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                //First see if program activated, if not load the activation form.
                // A sample valid Key is: 234567662
                //cPublicObjects.Settings.ValidationCode = "";
                //cPublicObjects.Settings.Save();
                cActivationCode oAct = new cActivationCode();
                if (!oAct.IsCodeValid(cPublicObjects.Settings.ValidationCode))
                {
                    frmActivate oAFrm = new frmActivate();
                    oAFrm.ShowDialog();
                }

                //See if user entered a valid Key or using program as demo.
                cPublicObjects.bIsDemo = !oAct.IsCodeValid(cPublicObjects.Settings.ValidationCode);


                //instantiating the Bitmap
                this.mBitmap = new Bitmap(this.picMain.Width, this.picMain.Height);
                this.Text = cPublicObjects.sProductName;
                SetMenuCheckMark();
                LoadConfigeration();
                InitializePictureNodes();
                DrawPictureNodes();
                InitializeGuessNodes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in frmBrainGame_Load." + ex.Message);
            }
        }

        private void TimMain_Tick(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                EndGameAnnoucment();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in TimMain_Tick." + ex.Message);
            }
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                System.Environment.Exit(0);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in mnuExit_Click." + ex.Message);
            }
        }

        private void mnuAbout_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                frmAbout fAbout = new frmAbout();
                fAbout.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in mnuAbout_Click." + ex.Message);
            }
        }

        private void cmdHint_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (mbGameRuns)
                {
                    this.TimMain.Stop();

                    if (cPublicObjects.Settings.CustomReverseOrder && cPublicObjects.Settings.GameLevel == "C")
                    {
                        if (cPublicObjects.Settings.Sound)
                        {
                            cWSound.Play("beep" + this.mPictureNodes[this.mGuessNodes[this.mGuessLevel - this.mGuessCurrent].Value].Sound.ToString() + ".wav", cWSound.SND_ASYNC);
                        }
                        DemoToShowMistake(this.mGuessNodes[this.mGuessLevel - this.mGuessCurrent].Value);
                    }
                    else
                    {
                        if (cPublicObjects.Settings.Sound)
                        {
                            cWSound.Play("beep" + this.mPictureNodes[this.mGuessNodes[this.mGuessCurrent].Value].Sound.ToString() + ".wav", cWSound.SND_ASYNC);
                        }
                        DemoToShowMistake(this.mGuessNodes[this.mGuessCurrent].Value);
                    }
                    this.TimMain.Start();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in cmdHint_Click." + ex.Message);
            }
        }

        private void ShowProgressOnStatusbar()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (mbGameRuns)
                {
                    this.stbMain.Text = (mGuessLevel + 1).ToString() + " of " + mMaxGuess.ToString() + " - " + mGuessCurrent.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in ShowProgressOnStatusbar." + ex.Message);
            }
        }

        private void MenuGameLevelsClick(Object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (sender == this.mnuBeginner)
                {
                    this.mnuBeginner.Checked = true;
                    this.mnuIntermediate.Checked = false;
                    this.mnuExpert.Checked = false;
                    this.mnuOptions.Checked = false;
                    cPublicObjects.Settings.GameLevel = "B";
                    cPublicObjects.Settings.MaxOption = 4;
                    cPublicObjects.Settings.MaxGuess = 20;
                    cPublicObjects.Settings.Reposition = 0;
                    cPublicObjects.Settings.RepositionAfterSequence = false;
                    cPublicObjects.Settings.Save();
                    ClearRedrawPictures(true);
                }
                else if (sender == this.mnuIntermediate)
                {
                    this.mnuBeginner.Checked = false;
                    this.mnuIntermediate.Checked = true;
                    this.mnuExpert.Checked = false;
                    this.mnuOptions.Checked = false;
                    cPublicObjects.Settings.GameLevel = "I";
                    cPublicObjects.Settings.MaxOption = 6;
                    cPublicObjects.Settings.MaxGuess = 20;
                    cPublicObjects.Settings.Reposition = 4;
                    cPublicObjects.Settings.RepositionAfterSequence = false;
                    cPublicObjects.Settings.Save();
                    ClearRedrawPictures(true);
                }
                else if (sender == this.mnuExpert)
                {
                    this.mnuBeginner.Checked = false;
                    this.mnuIntermediate.Checked = false;
                    this.mnuExpert.Checked = true;
                    this.mnuOptions.Checked = false;
                    cPublicObjects.Settings.GameLevel = "E";
                    cPublicObjects.Settings.MaxOption = 12;
                    cPublicObjects.Settings.MaxGuess = 20;
                    cPublicObjects.Settings.Reposition = 1;
                    cPublicObjects.Settings.RepositionAfterSequence = true;
                    cPublicObjects.Settings.Save();
                    ClearRedrawPictures(true);
                }
                else if (sender == this.mnuOptions)
                {
                    this.mnuBeginner.Checked = false;
                    this.mnuIntermediate.Checked = false;
                    this.mnuExpert.Checked = false;
                    this.mnuOptions.Checked = true;
                    cPublicObjects.Settings.GameLevel = "C";
                    cPublicObjects.Options.ShowDialog();
                    ClearRedrawPictures(false);
                }
                else
                {
                    Console.WriteLine("Error in MenuGameLevelsClick...");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in MenuGameLevelsClick." + ex.Message);
            }
        }

        private void mnuBestScore_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                frmScore oFrm = new frmScore();
                oFrm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in mnuBestScore_Click." + ex.Message);
            }
        }

        private void cmdEnd_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (mbGameRuns)
                {
                    this.EndGameAnnoucment();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in cmdEnd_Click." + ex.Message);
            }
        }

        private void mnuNewGame_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.cmdStart_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in mnuNewGame_Click." + ex.Message);
            }
        }

        private void mnuContents_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.Cursor = Cursors.WaitCursor;
                System.Diagnostics.Process.Start("SugarSimonHelp.htm");
                this.Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Error: Error in mnuContents_Click." + ex.Message);
            }

        }
    }
}