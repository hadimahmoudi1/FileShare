namespace BrainGame
{
    partial class frmActivate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmActivate));
            this.lblMessage = new System.Windows.Forms.Label();
            this.cmdOk = new System.Windows.Forms.Button();
            this.optKey = new System.Windows.Forms.RadioButton();
            this.txtKey = new System.Windows.Forms.TextBox();
            this.optBuy = new System.Windows.Forms.RadioButton();
            this.optDemo = new System.Windows.Forms.RadioButton();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMessage
            // 
            this.lblMessage.Location = new System.Drawing.Point(10, 7);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(238, 36);
            this.lblMessage.TabIndex = 0;
            this.lblMessage.Text = "Welcome! if you have purchased this program, please enter the activation key now." +
                "";
            // 
            // cmdOk
            // 
            this.cmdOk.Location = new System.Drawing.Point(106, 136);
            this.cmdOk.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmdOk.Name = "cmdOk";
            this.cmdOk.Size = new System.Drawing.Size(56, 27);
            this.cmdOk.TabIndex = 1;
            this.cmdOk.Text = "&OK";
            this.cmdOk.UseVisualStyleBackColor = true;
            this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
            // 
            // optKey
            // 
            this.optKey.AutoSize = true;
            this.optKey.Location = new System.Drawing.Point(12, 46);
            this.optKey.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.optKey.Name = "optKey";
            this.optKey.Size = new System.Drawing.Size(87, 17);
            this.optKey.TabIndex = 2;
            this.optKey.TabStop = true;
            this.optKey.Text = "I have a key:";
            this.optKey.UseVisualStyleBackColor = true;
            // 
            // txtKey
            // 
            this.txtKey.Location = new System.Drawing.Point(97, 45);
            this.txtKey.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtKey.Name = "txtKey";
            this.txtKey.Size = new System.Drawing.Size(134, 20);
            this.txtKey.TabIndex = 3;
            this.txtKey.GotFocus += new System.EventHandler(this.txtKey_GotFocus);
            // 
            // optBuy
            // 
            this.optBuy.AutoSize = true;
            this.optBuy.Location = new System.Drawing.Point(12, 76);
            this.optBuy.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.optBuy.Name = "optBuy";
            this.optBuy.Size = new System.Drawing.Size(206, 17);
            this.optBuy.TabIndex = 4;
            this.optBuy.TabStop = true;
            this.optBuy.Text = "Purchase activation key from the web.";
            this.optBuy.UseVisualStyleBackColor = true;
            // 
            // optDemo
            // 
            this.optDemo.Location = new System.Drawing.Point(12, 91);
            this.optDemo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.optDemo.Name = "optDemo";
            this.optDemo.Size = new System.Drawing.Size(209, 41);
            this.optDemo.TabIndex = 5;
            this.optDemo.TabStop = true;
            this.optDemo.Text = "Continue using as evaluation version. (Limited to 5 iterations)";
            this.optDemo.UseVisualStyleBackColor = true;
            // 
            // cmdCancel
            // 
            this.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancel.Location = new System.Drawing.Point(174, 136);
            this.cmdCancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(56, 27);
            this.cmdCancel.TabIndex = 6;
            this.cmdCancel.Text = "&Cancel";
            this.cmdCancel.UseVisualStyleBackColor = true;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // frmActivate
            // 
            this.AcceptButton = this.cmdOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cmdCancel;
            this.ClientSize = new System.Drawing.Size(239, 185);
            this.ControlBox = false;
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.optDemo);
            this.Controls.Add(this.optBuy);
            this.Controls.Add(this.txtKey);
            this.Controls.Add(this.optKey);
            this.Controls.Add(this.cmdOk);
            this.Controls.Add(this.lblMessage);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmActivate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmActivate";
            this.Load += new System.EventHandler(this.frmActivate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button cmdOk;
        private System.Windows.Forms.RadioButton optKey;
        private System.Windows.Forms.TextBox txtKey;
        private System.Windows.Forms.RadioButton optBuy;
        private System.Windows.Forms.RadioButton optDemo;
        private System.Windows.Forms.Button cmdCancel;
    }
}