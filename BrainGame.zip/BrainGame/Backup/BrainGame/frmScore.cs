/*
Pre:   None
Post:
Assert:

Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

Revision History:

[ 0]  Date:	By:		Version:	Action:
[ 1]  07/26/06	Hadi	1.000		Initial design.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BrainGame
{
    public partial class frmScore : Form
    {
        public frmScore()
        {
            InitializeComponent();
        }

        private void frmScore_Load(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.Text = cPublicObjects.sProductName;
                this.lblBeginnerName.Text = cPublicObjects.Settings.BeginnerUserName;
                this.lblIntermediateName.Text = cPublicObjects.Settings.IntermediateUserName;
                this.lblExpertName.Text = cPublicObjects.Settings.ExpertUserName;

                this.lblBeginnerScore.Text = cPublicObjects.Settings.ScoreBeginner.ToString();
                this.lblIntermediateScore.Text = cPublicObjects.Settings.ScoreIntermediate.ToString();
                this.lblExpertScore.Text = cPublicObjects.Settings.ScoreExpert.ToString();

                this.cmdOk.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in frmScore_Load." + ex.Message);
            }
        }

        private void cmdOk_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in frmScore_Load." + ex.Message);
            }
        }

        private void cmdResetScore_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                cPublicObjects.Settings.BeginnerUserName = "Anonymous";
                cPublicObjects.Settings.IntermediateUserName = "Anonymous";
                cPublicObjects.Settings.ExpertUserName = "Anonymous";

                cPublicObjects.Settings.ScoreBeginner = 0;
                cPublicObjects.Settings.ScoreIntermediate = 0;
                cPublicObjects.Settings.ScoreExpert = 0;

                cPublicObjects.Settings.Save();

                this.lblBeginnerName.Text = cPublicObjects.Settings.BeginnerUserName;
                this.lblIntermediateName.Text = cPublicObjects.Settings.IntermediateUserName;
                this.lblExpertName.Text = cPublicObjects.Settings.ExpertUserName;

                this.lblBeginnerScore.Text = cPublicObjects.Settings.ScoreBeginner.ToString();
                this.lblIntermediateScore.Text = cPublicObjects.Settings.ScoreIntermediate.ToString();
                this.lblExpertScore.Text = cPublicObjects.Settings.ScoreExpert.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in cmdResetScore_Click." + ex.Message);
            }

        }
    }
}