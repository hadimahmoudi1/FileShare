/*
Pre:   None
Post:
Assert:

Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

Revision History:

[ 0]  Date:	By:		Version:	Action:
[ 1]  07/26/06	Hadi	1.000		Initial design.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BrainGame
{
    public partial class frmAbout : Form
    {
        public frmAbout()
        {
            InitializeComponent();
        }

        private void frmAbout_Load(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.Text = cPublicObjects.sProductName;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in frmAbout_Load. " + ex.Message);
            }
        }

        private void lnkDarbod_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                System.Diagnostics.Process.Start("www.darbod.com");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in lnkDarbod_LinkClicked. " + ex.Message);
            }
        }
    }
}