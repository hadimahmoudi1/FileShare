/*
Pre:   None
Post:
Assert:

Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

Revision History:

[ 0]  Date:	By:		Version:	Action:
[ 1]  07/26/06	Hadi	1.000		Initial design.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BrainGame
{
    public partial class frmActivate : Form
    {
        public frmActivate()
        {
            InitializeComponent();
        }

        private void frmActivate_Load(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {

                this.Text = cPublicObjects.sProductName;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in frmActivate_Load. " + ex.Message);
            }
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                MessageBox.Show(cPublicObjects.sProductName + " had NOT been registered.");
                Application.Exit();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in cmdCancel_Click. " + ex.Message);
            }

        }

        private void cmdOk_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                if (this.optKey.Checked)
                {
                    cActivationCode oAct = new cActivationCode();
                    if (oAct.IsCodeValid(this.txtKey.Text))
                    {
                        cPublicObjects.Settings.ValidationCode = this.txtKey.Text;
                        cPublicObjects.Settings.Save();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Activation key is incorrect.");
                    }
                }
                if (this.optBuy.Checked)
                {
                    System.Diagnostics.Process.Start("www.darbod.com");
                }
                if (this.optDemo.Checked)
                {
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in cmdOk_Click. " + ex.Message);
            }

        }

        private void txtKey_GotFocus(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.optKey.Checked = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in txtKey_GotFocus. " + ex.Message);
            }
        }
    }
}