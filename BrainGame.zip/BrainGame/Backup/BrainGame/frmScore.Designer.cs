namespace BrainGame
{
    partial class frmScore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmScore));
            this.lblBeginner = new System.Windows.Forms.Label();
            this.lblIntermediate = new System.Windows.Forms.Label();
            this.lblExpert = new System.Windows.Forms.Label();
            this.lblBeginnerScore = new System.Windows.Forms.Label();
            this.lblIntermediateScore = new System.Windows.Forms.Label();
            this.lblExpertScore = new System.Windows.Forms.Label();
            this.lblExpertName = new System.Windows.Forms.Label();
            this.lblBeginnerName = new System.Windows.Forms.Label();
            this.lblIntermediateName = new System.Windows.Forms.Label();
            this.cmdResetScore = new System.Windows.Forms.Button();
            this.cmdOk = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBeginner
            // 
            this.lblBeginner.AutoSize = true;
            this.lblBeginner.Location = new System.Drawing.Point(16, 11);
            this.lblBeginner.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBeginner.Name = "lblBeginner";
            this.lblBeginner.Size = new System.Drawing.Size(69, 17);
            this.lblBeginner.TabIndex = 0;
            this.lblBeginner.Text = "Beginner:";
            // 
            // lblIntermediate
            // 
            this.lblIntermediate.AutoSize = true;
            this.lblIntermediate.Location = new System.Drawing.Point(16, 46);
            this.lblIntermediate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIntermediate.Name = "lblIntermediate";
            this.lblIntermediate.Size = new System.Drawing.Size(90, 17);
            this.lblIntermediate.TabIndex = 1;
            this.lblIntermediate.Text = "Intermediate:";
            // 
            // lblExpert
            // 
            this.lblExpert.AutoSize = true;
            this.lblExpert.Location = new System.Drawing.Point(16, 73);
            this.lblExpert.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblExpert.Name = "lblExpert";
            this.lblExpert.Size = new System.Drawing.Size(52, 17);
            this.lblExpert.TabIndex = 2;
            this.lblExpert.Text = "Expert:";
            // 
            // lblBeginnerScore
            // 
            this.lblBeginnerScore.AutoSize = true;
            this.lblBeginnerScore.Location = new System.Drawing.Point(119, 11);
            this.lblBeginnerScore.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBeginnerScore.Name = "lblBeginnerScore";
            this.lblBeginnerScore.Size = new System.Drawing.Size(0, 17);
            this.lblBeginnerScore.TabIndex = 3;
            // 
            // lblIntermediateScore
            // 
            this.lblIntermediateScore.AutoSize = true;
            this.lblIntermediateScore.Location = new System.Drawing.Point(119, 46);
            this.lblIntermediateScore.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIntermediateScore.Name = "lblIntermediateScore";
            this.lblIntermediateScore.Size = new System.Drawing.Size(0, 17);
            this.lblIntermediateScore.TabIndex = 4;
            // 
            // lblExpertScore
            // 
            this.lblExpertScore.AutoSize = true;
            this.lblExpertScore.Location = new System.Drawing.Point(119, 73);
            this.lblExpertScore.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblExpertScore.Name = "lblExpertScore";
            this.lblExpertScore.Size = new System.Drawing.Size(0, 17);
            this.lblExpertScore.TabIndex = 5;
            // 
            // lblExpertName
            // 
            this.lblExpertName.AutoSize = true;
            this.lblExpertName.Location = new System.Drawing.Point(177, 73);
            this.lblExpertName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblExpertName.Name = "lblExpertName";
            this.lblExpertName.Size = new System.Drawing.Size(0, 17);
            this.lblExpertName.TabIndex = 6;
            // 
            // lblBeginnerName
            // 
            this.lblBeginnerName.AutoSize = true;
            this.lblBeginnerName.Location = new System.Drawing.Point(176, 11);
            this.lblBeginnerName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBeginnerName.Name = "lblBeginnerName";
            this.lblBeginnerName.Size = new System.Drawing.Size(0, 17);
            this.lblBeginnerName.TabIndex = 7;
            // 
            // lblIntermediateName
            // 
            this.lblIntermediateName.AutoSize = true;
            this.lblIntermediateName.Location = new System.Drawing.Point(176, 46);
            this.lblIntermediateName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIntermediateName.Name = "lblIntermediateName";
            this.lblIntermediateName.Size = new System.Drawing.Size(0, 17);
            this.lblIntermediateName.TabIndex = 8;
            // 
            // cmdResetScore
            // 
            this.cmdResetScore.Location = new System.Drawing.Point(20, 102);
            this.cmdResetScore.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdResetScore.Name = "cmdResetScore";
            this.cmdResetScore.Size = new System.Drawing.Size(100, 28);
            this.cmdResetScore.TabIndex = 9;
            this.cmdResetScore.Text = "&Reset Score";
            this.cmdResetScore.UseVisualStyleBackColor = true;
            this.cmdResetScore.Click += new System.EventHandler(this.cmdResetScore_Click);
            // 
            // cmdOk
            // 
            this.cmdOk.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdOk.Location = new System.Drawing.Point(196, 102);
            this.cmdOk.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdOk.Name = "cmdOk";
            this.cmdOk.Size = new System.Drawing.Size(95, 28);
            this.cmdOk.TabIndex = 10;
            this.cmdOk.Text = "&OK";
            this.cmdOk.UseVisualStyleBackColor = true;
            this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
            // 
            // frmScore
            // 
            this.AcceptButton = this.cmdOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cmdOk;
            this.ClientSize = new System.Drawing.Size(296, 145);
            this.Controls.Add(this.cmdOk);
            this.Controls.Add(this.cmdResetScore);
            this.Controls.Add(this.lblIntermediateName);
            this.Controls.Add(this.lblBeginnerName);
            this.Controls.Add(this.lblExpertName);
            this.Controls.Add(this.lblExpertScore);
            this.Controls.Add(this.lblIntermediateScore);
            this.Controls.Add(this.lblBeginnerScore);
            this.Controls.Add(this.lblExpert);
            this.Controls.Add(this.lblIntermediate);
            this.Controls.Add(this.lblBeginner);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmScore";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Score";
            this.Load += new System.EventHandler(this.frmScore_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBeginner;
        private System.Windows.Forms.Label lblIntermediate;
        private System.Windows.Forms.Label lblExpert;
        private System.Windows.Forms.Label lblBeginnerScore;
        private System.Windows.Forms.Label lblIntermediateScore;
        private System.Windows.Forms.Label lblExpertScore;
        private System.Windows.Forms.Label lblExpertName;
        private System.Windows.Forms.Label lblBeginnerName;
        private System.Windows.Forms.Label lblIntermediateName;
        private System.Windows.Forms.Button cmdResetScore;
        private System.Windows.Forms.Button cmdOk;
    }
}