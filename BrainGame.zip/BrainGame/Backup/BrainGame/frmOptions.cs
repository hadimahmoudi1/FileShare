/*
Pre:   None
Post:
Assert:

Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

Revision History:

[ 0]  Date:	By:		Version:	Action:
[ 1]  07/26/06	Hadi	1.000		Initial design.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BrainGame
{
    public partial class frmOptions : Form
    {
        private bool mSound;
        private bool mReverseOrder;
        private int mMaxOption;
        private int mMaxGuess;
        private ShapeType mSelectShape;
        private int mReposition;
        private bool mbRepositionAfterSequence;

        public bool RepositionAfterSequence
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return mbRepositionAfterSequence;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in RepositionAfterSequence.Get. " + ex.Message);
                }
            }
            set
            {
                try
                {
                    mbRepositionAfterSequence = value;
                    this.chkRepositionAfter.Checked = value;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in RepositionAfterSequence.Set. " + ex.Message);
                }
            }
        }

        public int Reposition
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return mReposition;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in Reposition.Get. " + ex.Message);
                }
            }
            set
            {
                try
                {
                    mReposition = value;
                    this.cmbRepositionIteration.SelectedIndex = value;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in Reposition.Set. " + ex.Message);
                }
            }
        }
        
        public frmOptions()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            InitializeComponent();
        }
        
        public ShapeType Shape
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return mSelectShape;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in Shape.Get " + ex.Message);
                }
            }
            set
            {
                try
                {
                    mSelectShape = value;

                    if (mSelectShape == ShapeType.Circle)
                    {
                        this.optCircle.Checked = true;
                    }
                    if (mSelectShape == ShapeType.Rectangle)
                    {
                        this.optSquare.Checked = true;
                    }
                    if (mSelectShape == ShapeType.CarvedTriangle)
                    {
                        this.optCarvedTriangle.Checked = true;
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in Shape.Set " + ex.Message);
                }

            }
        }
        
        public int MaxGuess
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return mMaxGuess;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in MaxGuess.Get " + ex.Message);
                }
            }
            set
            {
                try
                {
                    mMaxGuess = value;
                    this.cboMaxGuess.Text = value.ToString();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in MaxGuess.Set " + ex.Message);
                }
            }
        }
        
        public int MaxOption
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return mMaxOption;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in MaxOption.Get " + ex.Message);
                }
            }
            set
            {
                try
                {
                    mMaxOption = value;
                    this.cboMaxOptions.Text = value.ToString();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in MaxOption.Set " + ex.Message);
                }
            }
        }
        
        public bool Sound
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return mSound;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in Sound.Get " + ex.Message);
                }
            }
            set
            {
                try
                {
                    mSound = value;
                    this.chkSound.Checked = value;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in Sound.Set " + ex.Message);
                }
            }
        }

        public bool ReverseOrder
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            get
            {
                try
                {
                    return mReverseOrder;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in ReverseOrder.Get " + ex.Message);
                }
            }
            set
            {
                try
                {
                    mReverseOrder = value;
                    this.chkReverseOrder.Checked = value;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error: Error in ReverseOrder.Set " + ex.Message);
                }
            }
        }

        private void cmdOk_Click(object sender, System.EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                SaveOptions();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in cmdOk_Click." + ex.Message);
            }
        }
        
        private void SaveOptions()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                cPublicObjects.Settings.CustomeSound = this.chkSound.Checked;
                cPublicObjects.Settings.CustomReverseOrder = this.chkReverseOrder.Checked;
                cPublicObjects.Settings.CustomMaxOption = Int32.Parse(this.cboMaxOptions.SelectedItem.ToString());
                cPublicObjects.Settings.CustomMaxGuess = Int32.Parse(this.cboMaxGuess.SelectedItem.ToString());
                if (this.optCircle.Checked)
                {
                    cPublicObjects.Settings.SelectShape = (int)ShapeType.Circle;
                }
                if (this.optSquare.Checked)
                {
                    cPublicObjects.Settings.SelectShape = (int)ShapeType.Rectangle;
                }
                if (this.optCarvedTriangle.Checked)
                {
                    cPublicObjects.Settings.SelectShape = (int)ShapeType.CarvedTriangle;
                }
                cPublicObjects.Settings.CustomReposition = this.cmbRepositionIteration.SelectedIndex;
                cPublicObjects.Settings.CustomRepositionAfterSequence = this.chkRepositionAfter.Checked;

                cPublicObjects.Settings.Sound = cPublicObjects.Settings.CustomeSound;
                cPublicObjects.Settings.MaxOption = cPublicObjects.Settings.CustomMaxOption;
                cPublicObjects.Settings.MaxGuess = cPublicObjects.Settings.CustomMaxGuess;
                cPublicObjects.Settings.Reposition = cPublicObjects.Settings.CustomReposition;
                cPublicObjects.Settings.RepositionAfterSequence = cPublicObjects.Settings.CustomRepositionAfterSequence;

                cPublicObjects.Settings.Save();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in SaveOptions." + ex.Message);
            }
        }

        private void frmOptions_Load(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.Text = cPublicObjects.sProductName;
                this.MaxOption = cPublicObjects.Settings.CustomMaxOption;
                this.MaxGuess = cPublicObjects.Settings.CustomMaxGuess;
                this.Reposition = cPublicObjects.Settings.CustomReposition;
                this.RepositionAfterSequence = cPublicObjects.Settings.CustomRepositionAfterSequence;
                this.Sound = cPublicObjects.Settings.CustomeSound;
                this.Shape = (ShapeType)cPublicObjects.Settings.SelectShape;
                this.ReverseOrder = cPublicObjects.Settings.CustomReverseOrder;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in frmOptions_Load." + ex.Message);
            }


        }

        private void cmdCancle_Click(object sender, EventArgs e)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Error in cmdCancle_Click." + ex.Message);
            }
        }

    }
}