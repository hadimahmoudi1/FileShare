/*
Pre:   None
Post:
Assert:

Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

Revision History:

[ 0]  Date:	By:		Version:	Action:
[ 1]  07/26/06	Hadi	1.000		Initial design.
*/

using System;

namespace BrainGame
{
    //For supporting images

    public enum ShapeType
    {
        Circle = 1,
        CarvedRectangle = 2,
        Rectangle = 3,
        CarvedTriangle = 4,
    }

    public class cPublicObjects
    {
        
        internal static string sProductName = "Sugar Simon";
        
        internal static bool bIsDemo = true;
        
        internal static frmOptions Options = new frmOptions();
        
        internal static BrainGame.Properties.Settings Settings = new BrainGame.Properties.Settings();
        
        internal static string InputBox(string prompt, string title, string defaultValue)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                frmInputBox ib = new frmInputBox();
                ib.FormPrompt = prompt;
                ib.FormCaption = title;
                ib.DefaultValue = defaultValue;
                ib.ShowDialog();
                string s = ib.InputResponse;
                ib.Close();
                return s;
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in InputBox. " + e.Message);
            }

        } // method: InputBox


    }
}
