namespace BrainGame
{
    partial class frmBrainGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBrainGame));
            this.mnuContents = new System.Windows.Forms.MenuItem();
            this.mnuSeperator3 = new System.Windows.Forms.MenuItem();
            this.mnuHelp = new System.Windows.Forms.MenuItem();
            this.mnuAbout = new System.Windows.Forms.MenuItem();
            this.mnuSeperator2 = new System.Windows.Forms.MenuItem();
            this.mnuExit = new System.Windows.Forms.MenuItem();
            this.cmdHint = new System.Windows.Forms.Button();
            this.TimMain = new System.Windows.Forms.Timer(this.components);
            this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
            this.tipMain = new System.Windows.Forms.ToolTip(this.components);
            this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
            this.picMain = new System.Windows.Forms.PictureBox();
            this.stbMain = new System.Windows.Forms.StatusBar();
            this.cmdStart = new System.Windows.Forms.Button();
            this.pbrStatus = new System.Windows.Forms.ProgressBar();
            this.mnuSeperator1 = new System.Windows.Forms.MenuItem();
            this.mnuOptions = new System.Windows.Forms.MenuItem();
            this.mnuNewGame = new System.Windows.Forms.MenuItem();
            this.mainMenu = new System.Windows.Forms.MainMenu(this.components);
            this.mnuGame = new System.Windows.Forms.MenuItem();
            this.mnuBeginner = new System.Windows.Forms.MenuItem();
            this.mnuIntermediate = new System.Windows.Forms.MenuItem();
            this.mnuExpert = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.mnuBestScore = new System.Windows.Forms.MenuItem();
            this.cmdEnd = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMain)).BeginInit();
            this.SuspendLayout();
            // 
            // mnuContents
            // 
            this.mnuContents.Index = 0;
            this.mnuContents.Shortcut = System.Windows.Forms.Shortcut.F1;
            this.mnuContents.Text = "How to Play";
            this.mnuContents.Click += new System.EventHandler(this.mnuContents_Click);
            // 
            // mnuSeperator3
            // 
            this.mnuSeperator3.Index = 1;
            this.mnuSeperator3.Text = "-";
            // 
            // mnuHelp
            // 
            this.mnuHelp.Index = 1;
            this.mnuHelp.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuContents,
            this.mnuSeperator3,
            this.mnuAbout});
            this.mnuHelp.Text = "Help";
            // 
            // mnuAbout
            // 
            this.mnuAbout.Index = 2;
            this.mnuAbout.Text = "About Brain Game ...";
            this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
            // 
            // mnuSeperator2
            // 
            this.mnuSeperator2.Index = 8;
            this.mnuSeperator2.Text = "-";
            // 
            // mnuExit
            // 
            this.mnuExit.Index = 9;
            this.mnuExit.Text = "Exit";
            this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
            // 
            // cmdHint
            // 
            this.cmdHint.Location = new System.Drawing.Point(8, 235);
            this.cmdHint.Name = "cmdHint";
            this.cmdHint.Size = new System.Drawing.Size(48, 23);
            this.cmdHint.TabIndex = 11;
            this.cmdHint.Text = "&Hint";
            this.cmdHint.Click += new System.EventHandler(this.cmdHint_Click);
            // 
            // TimMain
            // 
            this.TimMain.Interval = 4000;
            this.TimMain.Tick += new System.EventHandler(this.TimMain_Tick);
            // 
            // statusBarPanel2
            // 
            this.statusBarPanel2.Icon = ((System.Drawing.Icon)(resources.GetObject("statusBarPanel2.Icon")));
            this.statusBarPanel2.Name = "statusBarPanel2";
            this.statusBarPanel2.Text = "statusBarPanel2";
            // 
            // statusBarPanel1
            // 
            this.statusBarPanel1.Icon = ((System.Drawing.Icon)(resources.GetObject("statusBarPanel1.Icon")));
            this.statusBarPanel1.Name = "statusBarPanel1";
            this.statusBarPanel1.Text = "statusBarPanel1";
            // 
            // picMain
            // 
            this.picMain.BackColor = System.Drawing.Color.Black;
            this.picMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picMain.Location = new System.Drawing.Point(0, 3);
            this.picMain.Name = "picMain";
            this.picMain.Size = new System.Drawing.Size(226, 226);
            this.picMain.TabIndex = 10;
            this.picMain.TabStop = false;
            this.picMain.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picMain_MouseDown);
            // 
            // stbMain
            // 
            this.stbMain.Location = new System.Drawing.Point(0, 278);
            this.stbMain.Name = "stbMain";
            this.stbMain.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this.statusBarPanel1,
            this.statusBarPanel2});
            this.stbMain.Size = new System.Drawing.Size(225, 16);
            this.stbMain.TabIndex = 9;
            // 
            // cmdStart
            // 
            this.cmdStart.Location = new System.Drawing.Point(112, 235);
            this.cmdStart.Name = "cmdStart";
            this.cmdStart.Size = new System.Drawing.Size(103, 23);
            this.cmdStart.TabIndex = 8;
            this.cmdStart.Text = "&Start";
            this.cmdStart.Click += new System.EventHandler(this.cmdStart_Click);
            // 
            // pbrStatus
            // 
            this.pbrStatus.Location = new System.Drawing.Point(8, 264);
            this.pbrStatus.Name = "pbrStatus";
            this.pbrStatus.Size = new System.Drawing.Size(207, 13);
            this.pbrStatus.TabIndex = 7;
            // 
            // mnuSeperator1
            // 
            this.mnuSeperator1.Index = 1;
            this.mnuSeperator1.Text = "-";
            // 
            // mnuOptions
            // 
            this.mnuOptions.Index = 5;
            this.mnuOptions.RadioCheck = true;
            this.mnuOptions.Shortcut = System.Windows.Forms.Shortcut.F9;
            this.mnuOptions.Text = "Custom...";
            this.mnuOptions.Click += new System.EventHandler(this.MenuGameLevelsClick);
            // 
            // mnuNewGame
            // 
            this.mnuNewGame.Index = 0;
            this.mnuNewGame.Shortcut = System.Windows.Forms.Shortcut.F2;
            this.mnuNewGame.Text = "New";
            this.mnuNewGame.Click += new System.EventHandler(this.mnuNewGame_Click);
            // 
            // mainMenu
            // 
            this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuGame,
            this.mnuHelp});
            // 
            // mnuGame
            // 
            this.mnuGame.Index = 0;
            this.mnuGame.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuNewGame,
            this.mnuSeperator1,
            this.mnuBeginner,
            this.mnuIntermediate,
            this.mnuExpert,
            this.mnuOptions,
            this.menuItem2,
            this.mnuBestScore,
            this.mnuSeperator2,
            this.mnuExit});
            this.mnuGame.Text = "Game";
            // 
            // mnuBeginner
            // 
            this.mnuBeginner.Index = 2;
            this.mnuBeginner.RadioCheck = true;
            this.mnuBeginner.Shortcut = System.Windows.Forms.Shortcut.F6;
            this.mnuBeginner.Text = "Beginner";
            this.mnuBeginner.Click += new System.EventHandler(this.MenuGameLevelsClick);
            // 
            // mnuIntermediate
            // 
            this.mnuIntermediate.Index = 3;
            this.mnuIntermediate.RadioCheck = true;
            this.mnuIntermediate.Shortcut = System.Windows.Forms.Shortcut.F7;
            this.mnuIntermediate.Text = "Intermediate";
            this.mnuIntermediate.Click += new System.EventHandler(this.MenuGameLevelsClick);
            // 
            // mnuExpert
            // 
            this.mnuExpert.Index = 4;
            this.mnuExpert.RadioCheck = true;
            this.mnuExpert.Shortcut = System.Windows.Forms.Shortcut.F8;
            this.mnuExpert.Text = "Expert";
            this.mnuExpert.Click += new System.EventHandler(this.MenuGameLevelsClick);
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 6;
            this.menuItem2.Text = "-";
            // 
            // mnuBestScore
            // 
            this.mnuBestScore.Index = 7;
            this.mnuBestScore.Text = "Best Score...";
            this.mnuBestScore.Click += new System.EventHandler(this.mnuBestScore_Click);
            // 
            // cmdEnd
            // 
            this.cmdEnd.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdEnd.Location = new System.Drawing.Point(62, 235);
            this.cmdEnd.Margin = new System.Windows.Forms.Padding(2);
            this.cmdEnd.Name = "cmdEnd";
            this.cmdEnd.Size = new System.Drawing.Size(46, 23);
            this.cmdEnd.TabIndex = 12;
            this.cmdEnd.Text = "&End";
            this.cmdEnd.UseVisualStyleBackColor = true;
            this.cmdEnd.Click += new System.EventHandler(this.cmdEnd_Click);
            // 
            // frmBrainGame
            // 
            this.AcceptButton = this.cmdStart;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cmdEnd;
            this.ClientSize = new System.Drawing.Size(225, 294);
            this.Controls.Add(this.cmdEnd);
            this.Controls.Add(this.cmdHint);
            this.Controls.Add(this.picMain);
            this.Controls.Add(this.stbMain);
            this.Controls.Add(this.cmdStart);
            this.Controls.Add(this.pbrStatus);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Menu = this.mainMenu;
            this.Name = "frmBrainGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Brain Game";
            this.Load += new System.EventHandler(this.frmBrainGame_Load);
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMain)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuItem mnuContents;
        private System.Windows.Forms.MenuItem mnuSeperator3;
        private System.Windows.Forms.MenuItem mnuHelp;
        private System.Windows.Forms.MenuItem mnuAbout;
        private System.Windows.Forms.MenuItem mnuSeperator2;
        private System.Windows.Forms.MenuItem mnuExit;
        private System.Windows.Forms.Button cmdHint;
        private System.Windows.Forms.Timer TimMain;
        private System.Windows.Forms.StatusBarPanel statusBarPanel2;
        private System.Windows.Forms.ToolTip tipMain;
        private System.Windows.Forms.StatusBarPanel statusBarPanel1;
        private System.Windows.Forms.PictureBox picMain;
        private System.Windows.Forms.StatusBar stbMain;
        private System.Windows.Forms.Button cmdStart;
        private System.Windows.Forms.ProgressBar pbrStatus;
        private System.Windows.Forms.MenuItem mnuSeperator1;
        private System.Windows.Forms.MenuItem mnuOptions;
        private System.Windows.Forms.MenuItem mnuNewGame;
        private System.Windows.Forms.MainMenu mainMenu;
        private System.Windows.Forms.MenuItem mnuGame;
        private System.Windows.Forms.MenuItem menuItem2;
        private System.Windows.Forms.MenuItem mnuBestScore;
        private System.Windows.Forms.MenuItem mnuBeginner;
        private System.Windows.Forms.MenuItem mnuIntermediate;
        private System.Windows.Forms.MenuItem mnuExpert;
        private System.Windows.Forms.Button cmdEnd;
    }
}

