/*
Pre:   None
Post:
Assert:

Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

Revision History:

[ 0]  Date:	By:		Version:	Action:
[ 1]  07/26/06	Hadi	1.000		Initial design.
*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;


namespace BrainGame
{

    static class cWSound
    {
        [DllImport("WinMM.dll")]
        private static extern bool PlaySound(string fname, int Mod, int flag);
        // these are the SoundFlags we are using here
        public static int SND_ASYNC = 0x0001;     // play asynchronously
        public static int SND_FILENAME = 0x00020000; // use file name
        public static int SND_PURGE = 0x0040;     // purge non-static events

        public static int SND_SYNC = 0x0000;
        public static int SND_NODEFAULT = 0x0002;
        public static int SND_LOOP = 0x0008;
        public static int SND_NOSTOP = 0x0010;
        public static int SND_NOWAIT = 0x00002000;
        public static int SND_RESOURCE = 0x00040004;


        public static void Play(string fname, int SoundFlags)
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                PlaySound(fname, 0, SoundFlags);
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in Play. " + e.Message);
            }
        }

        public static void StopPlay()
        {
            /*
            Pre:   None
            Post:
            Assert:

            Author(s):Hadi Mahmoudi   HadiMahmoudi@hotmail.com

            Revision History:

            [ 0]  Date:	By:		Version:	Action:
            [ 1]  07/26/06	Hadi	1.000		Initial design.
            */
            try
            {
                PlaySound(null, 0, SND_PURGE);
            }
            catch (Exception e)
            {
                throw new Exception("Error: Error in StopPlay. " + e.Message);
            }
        }
    }



}
