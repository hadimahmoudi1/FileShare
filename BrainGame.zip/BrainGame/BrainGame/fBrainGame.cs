using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;


namespace BrainGame
{
	
	public class fBrainGame : System.Windows.Forms.Form
	{
		
		[DllImport("kernel32.dll")]
		public static extern  bool Beep(int freq,int duration);

		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem mnuNewGame;
		private System.Windows.Forms.MenuItem mnuContents;
		private System.Windows.Forms.MenuItem mnuOptions;
		private System.Windows.Forms.MenuItem mnuExit;
		private System.Windows.Forms.MenuItem mnuSeperator1;
		private System.Windows.Forms.MenuItem mnuSeperator2;
		private System.Windows.Forms.MenuItem mnuSeperator3;
		private System.Windows.Forms.MenuItem mnuGame;
		private System.Windows.Forms.MenuItem mnuHelp;
		private System.Windows.Forms.MenuItem mnuAbout;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.ProgressBar pbrStatus;
		private System.Windows.Forms.Button cmdStart;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel2;
		private System.Windows.Forms.PictureBox picMain;
		
		// Application Variables
		private int miDelay;
		public int mMaxGuess;
		private int maxOptions;
		private int mGuessLevel;
		private int mGuessCurrent;
		private Bitmap mBitmap;
		private cPictureNode[] mPictureNodes;
		private System.Windows.Forms.Timer TimMain;
		private System.Windows.Forms.Button cmdHint;
		private cGuessNode[] mGuessNodes;

		

		public fBrainGame()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(fBrainGame));
			this.button1 = new System.Windows.Forms.Button();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuGame = new System.Windows.Forms.MenuItem();
			this.mnuNewGame = new System.Windows.Forms.MenuItem();
			this.mnuSeperator1 = new System.Windows.Forms.MenuItem();
			this.mnuOptions = new System.Windows.Forms.MenuItem();
			this.mnuSeperator2 = new System.Windows.Forms.MenuItem();
			this.mnuExit = new System.Windows.Forms.MenuItem();
			this.mnuHelp = new System.Windows.Forms.MenuItem();
			this.mnuContents = new System.Windows.Forms.MenuItem();
			this.mnuSeperator3 = new System.Windows.Forms.MenuItem();
			this.mnuAbout = new System.Windows.Forms.MenuItem();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.pbrStatus = new System.Windows.Forms.ProgressBar();
			this.cmdStart = new System.Windows.Forms.Button();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
			this.picMain = new System.Windows.Forms.PictureBox();
			this.TimMain = new System.Windows.Forms.Timer(this.components);
			this.cmdHint = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(96, 280);
			this.button1.Name = "button1";
			this.button1.TabIndex = 0;
			this.button1.Text = "button1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuGame,
																					  this.mnuHelp});
			// 
			// mnuGame
			// 
			this.mnuGame.Index = 0;
			this.mnuGame.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuNewGame,
																					this.mnuSeperator1,
																					this.mnuOptions,
																					this.mnuSeperator2,
																					this.mnuExit});
			this.mnuGame.Text = "Game";
			// 
			// mnuNewGame
			// 
			this.mnuNewGame.Index = 0;
			this.mnuNewGame.Shortcut = System.Windows.Forms.Shortcut.F2;
			this.mnuNewGame.Text = "New Game";
			this.mnuNewGame.Click += new System.EventHandler(this.mnuNewGame_Click);
			// 
			// mnuSeperator1
			// 
			this.mnuSeperator1.Index = 1;
			this.mnuSeperator1.Text = "-";
			// 
			// mnuOptions
			// 
			this.mnuOptions.Index = 2;
			this.mnuOptions.Shortcut = System.Windows.Forms.Shortcut.F5;
			this.mnuOptions.Text = "Options";
			this.mnuOptions.Click += new System.EventHandler(this.mnuOptions_Click);
			// 
			// mnuSeperator2
			// 
			this.mnuSeperator2.Index = 3;
			this.mnuSeperator2.Text = "-";
			// 
			// mnuExit
			// 
			this.mnuExit.Index = 4;
			this.mnuExit.Text = "Exit";
			this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
			// 
			// mnuHelp
			// 
			this.mnuHelp.Index = 1;
			this.mnuHelp.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuContents,
																					this.mnuSeperator3,
																					this.mnuAbout});
			this.mnuHelp.Text = "Help";
			// 
			// mnuContents
			// 
			this.mnuContents.Index = 0;
			this.mnuContents.Shortcut = System.Windows.Forms.Shortcut.F1;
			this.mnuContents.Text = "Contents";
			// 
			// mnuSeperator3
			// 
			this.mnuSeperator3.Index = 1;
			this.mnuSeperator3.Text = "-";
			// 
			// mnuAbout
			// 
			this.mnuAbout.Index = 2;
			this.mnuAbout.Text = "About Brain Game ...";
			this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
			// 
			// pbrStatus
			// 
			this.pbrStatus.Location = new System.Drawing.Point(8, 312);
			this.pbrStatus.Name = "pbrStatus";
			this.pbrStatus.Size = new System.Drawing.Size(232, 16);
			this.pbrStatus.TabIndex = 1;
			// 
			// cmdStart
			// 
			this.cmdStart.Location = new System.Drawing.Point(184, 280);
			this.cmdStart.Name = "cmdStart";
			this.cmdStart.Size = new System.Drawing.Size(48, 23);
			this.cmdStart.TabIndex = 2;
			this.cmdStart.Text = "&Start";
			this.cmdStart.Click += new System.EventHandler(this.cmdStart_Click);
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 337);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.statusBarPanel1,
																						  this.statusBarPanel2});
			this.statusBar1.Size = new System.Drawing.Size(240, 16);
			this.statusBar1.TabIndex = 3;
			this.statusBar1.Text = "stbMain";
			// 
			// statusBarPanel1
			// 
			this.statusBarPanel1.Icon = ((System.Drawing.Icon)(resources.GetObject("statusBarPanel1.Icon")));
			this.statusBarPanel1.Text = "statusBarPanel1";
			// 
			// statusBarPanel2
			// 
			this.statusBarPanel2.Icon = ((System.Drawing.Icon)(resources.GetObject("statusBarPanel2.Icon")));
			this.statusBarPanel2.Text = "statusBarPanel2";
			// 
			// picMain
			// 
			this.picMain.BackColor = System.Drawing.Color.Black;
			this.picMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.picMain.Location = new System.Drawing.Point(8, 8);
			this.picMain.Name = "picMain";
			this.picMain.Size = new System.Drawing.Size(224, 256);
			this.picMain.TabIndex = 4;
			this.picMain.TabStop = false;
			this.picMain.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picMain_MouseDown);
			// 
			// TimMain
			// 
			this.TimMain.Interval = 4000;
			this.TimMain.Tick += new System.EventHandler(this.TimMain_Tick);
			// 
			// cmdHint
			// 
			this.cmdHint.Location = new System.Drawing.Point(16, 280);
			this.cmdHint.Name = "cmdHint";
			this.cmdHint.Size = new System.Drawing.Size(56, 23);
			this.cmdHint.TabIndex = 5;
			this.cmdHint.Text = "&Hint";
			this.cmdHint.Click += new System.EventHandler(this.cmdHint_Click);
			// 
			// fBrainGame
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(240, 353);
			this.Controls.Add(this.cmdHint);
			this.Controls.Add(this.picMain);
			this.Controls.Add(this.statusBar1);
			this.Controls.Add(this.cmdStart);
			this.Controls.Add(this.pbrStatus);
			this.Controls.Add(this.button1);
			this.Menu = this.mainMenu1;
			this.Name = "fBrainGame";
			this.Text = "Brain Game";
			this.Load += new System.EventHandler(this.fBrainGame_Load);
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		
		[STAThread]
		static void Main() 
		{
			Application.Run(new fBrainGame());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			//Microsoft.VisualBasic.Interaction.Beep();
			for (int i=0;i<10;i++)
			{
				Beep(i*500,100);
			}
		}

		private void mnuNewGame_Click(object sender, System.EventArgs e)
		{
			cmdStart_Click(sender,e);
		}

		private void cmdStart_Click(object sender, System.EventArgs e)
		{
			this.TimMain.Stop();
			RandomizeNodes();
			mGuessLevel = 0;
			miDelay = 300;
			this.pbrStatus.Value = mGuessLevel;
			mGuessCurrent = 0;
			StartSequance();
			this.TimMain.Start();
		}

		private void StartSequance()
		{

			for (int i=0;i <= this.mGuessLevel && this.mGuessLevel < this.mMaxGuess;i++)
			{
				Demo (this.mGuessNodes[i].Value);
			}
			
		}
		private void DemoToShowMistake(int Item)
		{
			const int iDelay = 50;
			if (Item>-1)
			{
				for (int i=1; i<8; i++)
				{
					this.mPictureNodes[Item].Show(this.mBitmap);
					this.picMain.Refresh();
					if (cPublicObjects.Options.Sound)
					{
						Beep(this.mPictureNodes[Item].Sound,iDelay);
					}
					else
						//No Beep But show the delay.
					{
						System.Threading.Thread.Sleep(iDelay);
					}
					this.mPictureNodes[Item].DrawImage(this.mBitmap);
					this.picMain.Refresh();
					System.Threading.Thread.Sleep(iDelay);
				}
				
			}
		}
		private void Demo(int Item)
		{
			
			if (Item>-1)
			{
				this.mPictureNodes[Item].Show(this.mBitmap);
				this.picMain.Refresh();
				if (cPublicObjects.Options.Sound)
				{
					Beep(this.mPictureNodes[Item].Sound,miDelay);
				}
				else
				//No Beep But show the delay.
				{
					System.Threading.Thread.Sleep(miDelay);
				}
				this.mPictureNodes[Item].DrawImage(this.mBitmap);
				this.picMain.Refresh();
				System.Threading.Thread.Sleep(100);
			}
		}

		private void picMain_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			int ClickValue = -1;
			this.picMain.Image = this.mBitmap;
			Color pixelColor = this.mBitmap.GetPixel(e.X, e.Y);
			ClickValue = GetValueByColor(pixelColor);
			Demo(ClickValue);
			if (this.mGuessNodes[this.mGuessCurrent].IsRight(ClickValue))
			{
				//IF we still need to go to get to the end of sequance.
				if (this.mGuessCurrent < this.mGuessLevel)
				{
					this.TimMain.Stop();
					this.TimMain.Start();
				}
				//IF we get to the end of sequance and we are not done.
				if (this.mGuessCurrent == this.mGuessLevel && this.mGuessCurrent != this.mMaxGuess-1)
				{
					this.TimMain.Stop();
					System.Threading.Thread.Sleep(500);	//MAke a delay at the end of sequance.
					mGuessLevel++;
					mGuessCurrent= -1; //-1 because we are going to increment it by 1 so  = 0 
					StartSequance();
					this.TimMain.Start();
					this.pbrStatus.Value = this.mGuessLevel;
				}

				if (this.mGuessCurrent == this.mGuessLevel && this.mGuessCurrent == this.mMaxGuess-1)
				{
					mGuessLevel++;
					this.pbrStatus.Value = this.mGuessLevel;
					this.WinGameAnnoucment();
				}
				//Increment to the next guess.
				this.mGuessCurrent++;
				IncreaseSpeed(mGuessCurrent);
				
			}
			else
			{
				//User made a mistake.
				EndGameAnnoucment();
			}
		}

		private void IncreaseSpeed(int Item)
		{
			if (miDelay >=300 && Item >= 5)
			{
				miDelay = 200;
			}
			else
			{
				if (miDelay >=200 && Item >= 10)
				{
					miDelay = 100;
				}
				else
				{
					if (miDelay >=100 && Item >= 15)
					{
						miDelay = 50;
					}
				}
			}
		}
		
		private void EndGameAnnoucment()
		{
			this.TimMain.Stop();
			DemoToShowMistake(this.mGuessNodes[this.mGuessCurrent].Value);
			MessageBox.Show("End of the game.");
		}

		private void WinGameAnnoucment()
		{
			this.TimMain.Stop();
			MessageBox.Show("Congradulations...");
		}

		private void fBrainGame_Load(object sender, System.EventArgs e)
		{
			//instantiating the Bitmap
			this.mBitmap = new Bitmap(this.picMain.Width,this.picMain.Height);
			LoadConfigeration();
			DrawPictureNodes();
			InitializeGuessNodes();
		}

		
		private void DrawPictureNodes()
		{
			mPictureNodes = new cPictureNode[maxOptions];
			
			for (int i=0 ; i<maxOptions ; i++)
			{
				mPictureNodes[i] = new cPictureNode();
				mPictureNodes[i].oNodeShape = ShapeType.Circle;
				mPictureNodes[i].MaxValue= maxOptions;
				mPictureNodes[i].Sound = (i+1) * 500;
				mPictureNodes[i].Value= i+1;
				mPictureNodes[i].DrawImage(this.mBitmap);
				
			}

			this.picMain.Image = this.mBitmap;

		}
		

		private void RandomizeNodes()
		{

			for (int i=0 ; i<mMaxGuess ; i++)
			{
				mGuessNodes[i].Randomize();
			}
		}
		private void InitializeGuessNodes()
		{
			mGuessNodes = new cGuessNode[mMaxGuess];
			
			for (int i=0 ; i<mMaxGuess ; i++)
			{
				mGuessNodes[i] = new cGuessNode();
				mGuessNodes[i].MaxValue= maxOptions;
				mGuessNodes[i].Randomize();
			}
		}

		private void TimMain_Tick(object sender, System.EventArgs e)
		{
			EndGameAnnoucment();
		}

		private int GetValueByColor(Color pixelColor)
		{
			for ( int i=0;i<this.maxOptions;i++)
			{
				if (
					(pixelColor.R == this.mPictureNodes[i].Color.R)
					&& (pixelColor.G == this.mPictureNodes[i].Color.G)
					&& (pixelColor.B == this.mPictureNodes[i].Color.B))
				{
					return i;
				}
			}
			//Did not find.
			return -1;
		}
		
		private void LoadConfigeration()
		{
			
			if (cPublicObjects.Options.MaxOption==0)
			{
				maxOptions = 4; 
			}
			else
			{
				maxOptions = cPublicObjects.Options.MaxOption;
			}
			if (cPublicObjects.Options.MaxGuess==0)
			{
				mMaxGuess = 20; 
			}
			else
			{
				mMaxGuess = cPublicObjects.Options.MaxGuess;
			}
			
			this.pbrStatus.Maximum = mMaxGuess;
 
		}

		private void mnuOptions_Click(object sender, System.EventArgs e)
		{
			cPublicObjects.Options.ShowDialog();
			//Start after option is done.
			this.fBrainGame_Load(sender,  e);
			
		}

		private void mnuExit_Click(object sender, System.EventArgs e)
		{
			System.Environment.Exit(0);
			
		}

		private void mnuAbout_Click(object sender, System.EventArgs e)
		{
			frmAbout fAbout = new frmAbout();
			fAbout.Show();
		}

		private void cmdHint_Click(object sender, System.EventArgs e)
		{
			this.TimMain.Stop();
			DemoToShowMistake(this.mGuessNodes[this.mGuessCurrent].Value);
			this.TimMain.Start();
		}
	}
}
